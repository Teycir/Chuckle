"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res) => function __init() {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };

  // src/loading.ts
  function showLoading(message = "Generating meme...") {
    if (loadingOverlay) return;
    loadingOverlay = document.createElement("div");
    loadingOverlay.className = "loading-overlay";
    const spinner = document.createElement("div");
    spinner.className = "loading-spinner";
    const text = document.createElement("div");
    text.className = "loading-text";
    text.textContent = message;
    loadingOverlay.appendChild(spinner);
    loadingOverlay.appendChild(text);
    document.body.appendChild(loadingOverlay);
  }
  function hideLoading() {
    if (loadingOverlay) {
      loadingOverlay.remove();
      loadingOverlay = null;
    }
  }
  var loadingOverlay;
  var init_loading = __esm({
    "src/loading.ts"() {
      "use strict";
      loadingOverlay = null;
    }
  });

  // lib/logger.ts
  var Logger;
  var init_logger = __esm({
    "lib/logger.ts"() {
      "use strict";
      Logger = class {
        constructor(prefix, debug = false) {
          this.prefix = prefix;
          this.debug = debug;
        }
        /**
         * Log informational message (only in debug mode)
         */
        info(message, ...args) {
          if (this.debug) console.log(`[${this.prefix}] ${message}`, ...args);
        }
        /**
         * Log error message (always shown)
         */
        error(message, error) {
          console.error(`[${this.prefix} Error] ${message}`, error);
        }
        /**
         * Log warning message (only in debug mode)
         */
        warn(message, ...args) {
          if (this.debug) console.warn(`[${this.prefix} Warning] ${message}`, ...args);
        }
      };
    }
  });

  // src/logger.ts
  var DEBUG, logger;
  var init_logger2 = __esm({
    "src/logger.ts"() {
      "use strict";
      init_logger();
      DEBUG = false;
      logger = new Logger("Chuckle", DEBUG);
    }
  });

  // src/config.ts
  var CONFIG;
  var init_config = __esm({
    "src/config.ts"() {
      "use strict";
      CONFIG = {
        IMGFLIP_API_URL: "https://api.imgflip.com/caption_image",
        MEMEGEN_API_URL: "https://api.memegen.link/images",
        FALLBACK_IMAGE_URL: "https://api.memegen.link/images/drake/meme_generation_failed/please_try_again.png",
        DEBOUNCE_DELAY: 150,
        MAX_TAG_LENGTH: 100,
        MAX_HISTORY_ITEMS: 1e3,
        MAX_UNDO_STACK: 20,
        CACHE_TTL_MS: 36e5
      };
    }
  });

  // lib/lru-cache.ts
  var LRUCache;
  var init_lru_cache = __esm({
    "lib/lru-cache.ts"() {
      "use strict";
      LRUCache = class {
        /**
         * Creates a new LRU Cache
         * @param maxSize - Maximum number of entries (default: 100)
         * @param ttlMs - Time to live in milliseconds (default: 3600000 = 1 hour)
         */
        constructor(maxSize = 100, ttlMs = 36e5) {
          this.cache = /* @__PURE__ */ new Map();
          this.maxSize = maxSize;
          this.ttl = ttlMs;
        }
        /**
         * Gets a value from cache
         * @param key - Cache key
         * @returns Cached value or null if not found/expired
         */
        get(key) {
          const entry = this.cache.get(key);
          if (!entry) return null;
          if (Date.now() - entry.timestamp > this.ttl) {
            this.cache.delete(key);
            return null;
          }
          this.cache.delete(key);
          this.cache.set(key, entry);
          return entry.value;
        }
        /**
         * Sets a value in cache
         * @param key - Cache key
         * @param value - Value to cache
         */
        set(key, value) {
          if (this.cache.size >= this.maxSize) {
            const firstKey = this.cache.keys().next().value;
            if (firstKey) this.cache.delete(firstKey);
          }
          this.cache.set(key, { value, timestamp: Date.now() });
        }
        /**
         * Clears all entries from cache
         */
        clear() {
          this.cache.clear();
        }
      };
    }
  });

  // src/cache.ts
  var geminiCache, formattedCache;
  var init_cache = __esm({
    "src/cache.ts"() {
      "use strict";
      init_lru_cache();
      geminiCache = new LRUCache();
      formattedCache = new LRUCache(100, 36e5);
    }
  });

  // src/constants.ts
  var MEME_TEMPLATES, GEMINI_PROMPT_TEMPLATE, API_KEY_REGEX;
  var init_constants = __esm({
    "src/constants.ts"() {
      "use strict";
      MEME_TEMPLATES = [
        { id: "drake", name: "Drake", topics: ["choice", "preference", "comparison", "rejection", "approval"] },
        { id: "db", name: "Distracted BF", topics: ["temptation", "distraction", "betrayal", "choice", "infidelity"] },
        { id: "ds", name: "Daily Struggle", topics: ["impossible choice", "dilemma", "absurd", "stress", "panic"] },
        { id: "cmm", name: "Change My Mind", topics: ["opinion", "debate", "controversial", "statement", "challenge"] },
        { id: "pigeon", name: "Pigeon", topics: ["confusion", "misunderstanding", "wrong", "mistake", "identification"] },
        { id: "woman-cat", name: "Woman Cat", topics: ["argument", "accusation", "defense", "dismissal", "conflict"] },
        { id: "fine", name: "This Is Fine", topics: ["denial", "disaster", "chaos", "cope", "fire"] },
        { id: "stonks", name: "Stonks", topics: ["success", "profit", "unexpected", "win", "growth"] },
        { id: "success", name: "Success Kid", topics: ["victory", "achievement", "win", "triumph", "celebration"] },
        { id: "blb", name: "Bad Luck Brian", topics: ["failure", "misfortune", "unlucky", "disaster", "backfire"] },
        { id: "fry", name: "Futurama Fry", topics: ["suspicion", "doubt", "uncertain", "paranoid", "question"] },
        { id: "fwp", name: "First World", topics: ["privilege", "complaint", "minor", "luxury", "trivial"] },
        { id: "doge", name: "Doge", topics: ["excitement", "enthusiasm", "wow", "much", "very"] },
        { id: "iw", name: "Insanity Wolf", topics: ["extreme", "crazy", "overreaction", "insane", "wild"] },
        { id: "philosoraptor", name: "Philosoraptor", topics: ["philosophy", "deep", "thinking", "paradox", "question"] },
        { id: "grumpycat", name: "Grumpy Cat", topics: ["grumpy", "rejection", "no", "refusal", "negative"] }
      ];
      GEMINI_PROMPT_TEMPLATE = (text, topic) => `Analyze this text and suggest ONE meme template from this list: db (distracted boyfriend), drake, ds (two buttons - sweating over impossible choices), cmm (change my mind), pigeon, woman-cat, fine (this is fine), stonks, success, blb (bad luck brian), fry (futurama fry), fwp (first world problems), doge, iw (insanity wolf), philosoraptor, grumpycat. Text: "${text}".${topic ? ` Topic: ${topic}.` : ""} Return ONLY the template ID (e.g., "db", "drake"). No explanation.`;
      API_KEY_REGEX = /^AIza[0-9A-Za-z_-]{35}$/;
    }
  });

  // src/errorMessages.ts
  async function getErrorMessage(key) {
    const { selectedLanguage } = await chrome.storage.local.get(["selectedLanguage"]);
    const lang = selectedLanguage || "English";
    return ERROR_MESSAGES[lang]?.[key] || ERROR_MESSAGES.English[key];
  }
  var ERROR_MESSAGES;
  var init_errorMessages = __esm({
    "src/errorMessages.ts"() {
      "use strict";
      ERROR_MESSAGES = {
        English: {
          tooManyRequests: "API exhausted. Please wait a moment and try again.",
          generationFailed: "Meme generation failed. Please try again.",
          noApiKey: "API key not configured. Please add your API key in settings.",
          invalidApiKey: "Invalid API key format.",
          networkError: "Network error. Check your internet connection.",
          templateUnavailable: "Template unavailable. Please try another template."
        },
        Spanish: {
          tooManyRequests: "API agotada. Por favor, espera un momento e int\xE9ntalo de nuevo.",
          generationFailed: "Generaci\xF3n de meme fallida. Por favor, int\xE9ntalo de nuevo.",
          noApiKey: "Clave API no configurada. Por favor, agrega tu clave API en la configuraci\xF3n.",
          invalidApiKey: "Formato de clave API inv\xE1lido.",
          networkError: "Error de red. Verifica tu conexi\xF3n a internet.",
          templateUnavailable: "Plantilla no disponible. Por favor, prueba otra plantilla."
        },
        French: {
          tooManyRequests: "API \xE9puis\xE9e. Veuillez attendre un moment et r\xE9essayer.",
          generationFailed: "\xC9chec de la g\xE9n\xE9ration du meme. Veuillez r\xE9essayer.",
          noApiKey: "Cl\xE9 API non configur\xE9e. Veuillez ajouter votre cl\xE9 API dans les param\xE8tres.",
          invalidApiKey: "Format de cl\xE9 API invalide.",
          networkError: "Erreur r\xE9seau. V\xE9rifiez votre connexion internet.",
          templateUnavailable: "Mod\xE8le non disponible. Veuillez essayer un autre mod\xE8le."
        },
        German: {
          tooManyRequests: "API ersch\xF6pft. Bitte warten Sie einen Moment und versuchen Sie es erneut.",
          generationFailed: "Meme-Generierung fehlgeschlagen. Bitte versuchen Sie es erneut.",
          noApiKey: "API-Schl\xFCssel nicht konfiguriert. Bitte f\xFCgen Sie Ihren API-Schl\xFCssel in den Einstellungen hinzu.",
          invalidApiKey: "Ung\xFCltiges API-Schl\xFCsselformat.",
          networkError: "Netzwerkfehler. \xDCberpr\xFCfen Sie Ihre Internetverbindung.",
          templateUnavailable: "Vorlage nicht verf\xFCgbar. Bitte versuchen Sie eine andere Vorlage."
        }
      };
    }
  });

  // src/watermark.ts
  async function addWatermark(imageUrl) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => {
        const canvas = document.createElement("canvas");
        const ctx = canvas.getContext("2d");
        if (!ctx) return reject(new Error("Canvas not supported"));
        canvas.width = img.width;
        canvas.height = img.height;
        ctx.drawImage(img, 0, 0);
        const fontSize = Math.max(12, img.height * 0.03);
        ctx.font = `${fontSize}px Arial`;
        ctx.fillStyle = "rgba(255, 255, 255, 0.8)";
        ctx.strokeStyle = "rgba(0, 0, 0, 0.5)";
        ctx.lineWidth = 2;
        const text = "teycirbensoltane.tn";
        const padding = 10;
        const x = img.width - ctx.measureText(text).width - padding;
        const y = img.height - padding;
        ctx.strokeText(text, x, y);
        ctx.fillText(text, x, y);
        resolve(canvas.toDataURL("image/png"));
      };
      img.onerror = () => reject(new Error("Failed to load image"));
      img.src = imageUrl;
    });
  }
  var init_watermark = __esm({
    "src/watermark.ts"() {
      "use strict";
    }
  });

  // lib/text-utils.ts
  function decodeHtmlEntities(text) {
    const entities = {
      "&quot;": '"',
      "&#34;": '"',
      "&apos;": "'",
      "&#39;": "'",
      "&amp;": "&",
      "&#38;": "&",
      "&lt;": "<",
      "&#60;": "<",
      "&gt;": ">",
      "&#62;": ">",
      "&nbsp;": " ",
      "&#160;": " "
    };
    return text.replace(/&[#a-z0-9]+;/gi, (match) => entities[match.toLowerCase()] || "");
  }
  function removeEmojis(text) {
    return text.replace(/[\u{1F300}-\u{1F9FF}]/gu, "").replace(/[\u{2600}-\u{26FF}]/gu, "").replace(/[\u{2700}-\u{27BF}]/gu, "");
  }
  function sanitizeText(text) {
    return text.replace(/[*#@]/g, "").replace(/\s+/g, " ").trim();
  }
  function cleanText(text) {
    return sanitizeText(removeEmojis(text));
  }
  var init_text_utils = __esm({
    "lib/text-utils.ts"() {
      "use strict";
    }
  });

  // src/templateFormatter.ts
  async function formatTextForTemplate(text, template, forceRegenerate = false) {
    const { offlineMode } = await chrome.storage.local.get(["offlineMode"]);
    if (offlineMode) {
      console.log("[Chuckle] Offline mode: splitting text in half");
      const words = text.trim().split(/\s+/);
      const mid = Math.ceil(words.length / 2);
      const part1 = words.slice(0, mid).join(" ");
      const part2 = words.slice(mid).join(" ");
      return `${part1} / ${part2}`;
    }
    const cacheKey = `fmt:${template}:${text.slice(0, 50)}`;
    if (!forceRegenerate) {
      const cached = formattedCache.get(cacheKey);
      if (cached) {
        console.log("[Chuckle] Using cached formatted text");
        return cached;
      }
    }
    const templatePrompt = TEMPLATE_PROMPTS[template] || 'Format as two parts: "part 1 / part 2" (max 35 chars each)';
    console.log(`[Chuckle] Formatting text for ${template}`);
    const { aiProvider, geminiApiKey, openrouterApiKey, primaryModel, openrouterPrimaryModel, selectedLanguage } = await chrome.storage.local.get(["aiProvider", "geminiApiKey", "openrouterApiKey", "primaryModel", "openrouterPrimaryModel", "selectedLanguage"]);
    const provider = aiProvider || "google";
    const language = selectedLanguage || "English";
    const model = provider === "google" ? primaryModel || "models/gemini-2.0-flash" : openrouterPrimaryModel || "meta-llama/llama-3.2-3b-instruct:free";
    if (provider === "google" && !geminiApiKey) throw new Error("No API key");
    if (provider === "openrouter" && !openrouterApiKey) throw new Error("No API key");
    const prompt = `Format: "${text}"

Template: ${templatePrompt}

RULES:
1. Return ONLY: "text1 / text2"
2. Each part MAX 70 chars
3. Language: ${language}
4. Be concise and viral
5. CRITICAL: Be concise and creative - rephrase to fit within 70 chars
6. NEVER truncate words ("du moin" is WRONG, must be "du moins" or rephrase entirely)
7. Plan your text from the start to fit 70 chars - write complete sentences that naturally fit
8. PREFER 3-4 words max in part 1 and part 2 IF POSSIBLE - shorter is punchier and more viral

CRITICAL - Choose ONE definitive answer:
- NO alternatives ("OR", "Alternatively", "could be")
- NO thinking process or commentary
- NO multiple options
- Just return the FINAL result

FORBIDDEN - DO NOT INCLUDE:
- Your thoughts
- Explanations
- Commentary
- "Let me", "Here is", "according to", "I will"
- ANY text outside the 2 parts

Response (ONLY the 2 parts):`;
    try {
      let response;
      if (provider === "google") {
        const modelName = model.replace("models/", "");
        const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent`;
        response = await fetch(`${apiUrl}?key=${geminiApiKey}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }],
            generationConfig: {
              temperature: 0.7,
              topP: 0.85,
              topK: 25,
              maxOutputTokens: 100
            }
          })
        });
      } else {
        response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${openrouterApiKey}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            model,
            messages: [{ role: "user", content: prompt }],
            temperature: 0.7,
            top_p: 0.85,
            max_tokens: 80
          })
        });
      }
      if (!response.ok) {
        if (response.status === 429) {
          const errorMsg = await getErrorMessage("tooManyRequests");
          throw new Error(errorMsg);
        }
        if (response.status === 403 || response.status === 401) {
          throw new Error(`API authentication failed (${response.status})`);
        }
        throw new Error(`API error: ${response.status}`);
      }
      const data = await response.json();
      let formatted;
      if (provider === "google") {
        formatted = data.candidates?.[0]?.content?.parts?.[0]?.text?.trim();
      } else {
        formatted = data.choices?.[0]?.message?.content?.trim();
      }
      console.log("[Chuckle] Raw AI response:", formatted);
      if (!formatted) {
        throw new Error("AI returned no visible text output");
      }
      if (formatted) {
        formatted = formatted.replace(/^["']|["']$/g, "").trim();
        formatted = decodeHtmlEntities(formatted);
        formatted = cleanText(formatted);
        const explanationMarkers = [" is not valid", " due to", "A valid", "rephrased version", "Let me", "according to", "Here is", "I will", "The formatted"];
        for (const marker of explanationMarkers) {
          const idx = formatted.toLowerCase().indexOf(marker.toLowerCase());
          if (idx > 0) {
            formatted = formatted.substring(0, idx).trim();
          }
        }
        formatted = formatted.replace(/["']+$/g, "").trim();
        const lines = formatted.split("\n").filter((l) => l.trim().length > 0);
        const firstLine = lines[0] || formatted;
        const separators = [" / ", "/", " /"];
        for (const sep of separators) {
          if (firstLine.includes(sep)) {
            const parts = firstLine.split(sep).map((p) => p.trim());
            if (parts.length >= 2 && parts[0] && parts[1]) {
              let part1 = parts[0];
              let part2 = parts[1];
              if (part1.length > 80) {
                const words = part1.split(/\s+/);
                part1 = "";
                for (const word of words) {
                  if ((part1 + " " + word).trim().length <= 80) {
                    part1 = (part1 + " " + word).trim();
                  } else break;
                }
              }
              if (part2.length > 80) {
                const words = part2.split(/\s+/);
                part2 = "";
                for (const word of words) {
                  if ((part2 + " " + word).trim().length <= 80) {
                    part2 = (part2 + " " + word).trim();
                  } else break;
                }
              }
              const cleanedLine = `${part1} / ${part2}`;
              console.log("[Chuckle] Text formatted for template:", cleanedLine, `(${part1.length}/${part2.length} chars)`);
              formattedCache.set(cacheKey, cleanedLine);
              return cleanedLine;
            }
          }
        }
      }
      throw new Error("AI failed to format with separator");
    } catch (error) {
      console.error("[Chuckle] Template formatting error:", error);
      if (error instanceof Error && (error.message.includes("429") || error.message.includes("API exhausted") || error.message.includes("API agotada") || error.message.includes("API \xE9puis\xE9e") || error.message.includes("API ersch\xF6pft") || error.message.includes("Too many requests") || error.message.includes("Too Many Requests"))) {
        throw error;
      }
      throw new Error(`Failed to format text for ${template}: ${error}`);
    }
  }
  var TEMPLATE_PROMPTS;
  var init_templateFormatter = __esm({
    "src/templateFormatter.ts"() {
      "use strict";
      init_errorMessages();
      init_cache();
      init_text_utils();
      TEMPLATE_PROMPTS = {
        drake: 'Drake (rejecting/approving): TOP=rejected option (what Drake pushes away), BOTTOM=OPPOSITE approved option (what Drake wants). CRITICAL: TOP and BOTTOM must be CONTRADICTORY. Example: TOP="Therapy and self-care" BOTTOM="Ignoring problems until they disappear". Photo: Drake rapper in red jacket, top panel shows him turning away disgusted, bottom panel shows him pointing and smiling approvingly.',
        db: 'Distracted Boyfriend: TOP=tempting new thing only, BOTTOM=current thing being ignored. About temptation only. Example: TOP="ChatGPT writing my code" BOTTOM="Actually learning to code". Photo: Man walking with girlfriend, turns to check out another woman passing by, girlfriend looks angry.',
        ds: 'Daily struggle (sweating): TOP=first equally horrible option, BOTTOM=second equally horrible option. CRITICAL: Both choices must be EQUALLY BAD/TERRIBLE - no good option exists. Example: TOP="Admit I was wrong" BOTTOM="Get fired". Photo: Man in suit sweating nervously, hand hovering over two red buttons, unable to choose.',
        cmm: 'Change My Mind: One single controversial statement (no TOP/BOTTOM split). Example: "Pineapple belongs on pizza". Photo: Man sitting at table with sign that says "Change My Mind", ready to debate.',
        pigeon: 'Pigeon (Is this...?): TOP=tiny/pathetic thing, BOTTOM="Is this [absurdly grand label]?". About ridiculous misidentification. Example: TOP="Got 3 likes on my post" BOTTOM="Am I megastar or superstar?". Photo: Pigeon looking at butterfly, confused about what it is.',
        "woman-cat": `Woman Yelling at Cat: TOP=angry woman yelling accusation, BOTTOM=cat SADISTIC response that ENJOYS the pain/problem. CRITICAL: Cat must be CRUEL, SADISTIC, take PLEASURE in the accusation, and respond with MALICIOUS satisfaction. Cat LOVES causing suffering. Example 1: TOP="You are ruining your life!" BOTTOM="And I'll do it again". Example 2: TOP="Ils nous divisent!" BOTTOM="Bien fait". Photo: Woman yelling (left), cat at table unbothered (right).`,
        fine: 'This is Fine (dog in fire): TOP=very catastrophic situation and desparate, BOTTOM=denial during disaster, accepting fate, extemely passive and accepting catastrophy, total submission. Example: TOP="Bank account at -$47, rent due tomorrow" BOTTOM="This is fine". Photo: Dog sitting at table drinking coffee while room is on fire around him, smiling calmly.',
        stonks: 'Stonks: TOP=huge failure/mistake, BOTTOM=unexpected huge success DESPITE the failure. CRITICAL: BOTTOM must be POSITIVE/WIN/SUCCESS, not another failure. Example: TOP="Accidentally replied all with meme" BOTTOM="CEO loved it, got promoted". Photo: Orange meme man in suit with rising stock chart arrow behind him, looking confident.',
        success: `Success Kid (fist pump): TOP=challenge/obstacle, BOTTOM=petty victory or savage comeback, winner attitude and optimism. Example: TOP="Ex said I'd never find better" BOTTOM="Now married to a top model". Photo: Baby on beach with determined expression, fist clenched in victory pose.`,
        blb: 'Bad Luck Brian: TOP=big action taken, BOTTOM=catastrophic outcome. Example: TOP="Finally gets a date" BOTTOM="She brings her boyfriend". Photo: Awkward teen with braces, red plaid vest, terrible school photo smile.',
        fry: 'Futurama Fry (squinting): TOP="Not sure if [first option]", BOTTOM="Or [second option]". Very paranoid, at limit of insanity. Example: TOP="Not sure if flirting" BOTTOM="Or is a Russian spy try to seduce me". Photo: Fry from Futurama squinting suspiciously, orange hair, red jacket.',
        fwp: 'First World Problems: TOP=ridiculously privileged complaint on a tiny problem, BOTTOM=why it ruins everything, extreme over reaction to a tiny problem. Spoiled brat question and answer. Example: TOP="My AirPods died" BOTTOM=" I am going to open my veins". Photo: Woman crying while holding phone, looking devastated over trivial problem.',
        doge: 'Doge: Broken English, enthusiastic. TOP="much/wow [thing]", BOTTOM="such/very [thing] wow". Funny breaking of the language. Example: TOP="much procrastinate" BOTTOM="very deadline panic wow". Photo: Shiba Inu dog with raised eyebrows, looking sideways with comic sans text.',
        iw: 'Insanity Wolf: TOP=normal situation, BOTTOM=EXTREME overreaction. Example: TOP="Someone says good morning" BOTTOM="SCREAM BACK AGGRESSIVELY". Be creative an hilarious, use exageration to the absurd. Photo: Wolf with crazy eyes, teeth bared, insane aggressive expression.',
        philosoraptor: `Philosoraptor: TOP=first part of mind-bending question, BOTTOM=second part that makes you think. Be creative an hilarious. Example: TOP="If I'm always late" BOTTOM="Am I consistently on time for being late?". Photo: Velociraptor in thinking pose, claw on chin, contemplating deeply.`,
        grumpycat: 'Grumpy Cat: TOP=suggestion/request, BOTTOM=witty grumpy rejection with extreme snobism and sarcasm. Be creative and hilarious to a point were we laugh hard, not just "No". Example: TOP="Be more positive" BOTTOM="I choose violence". Photo: Grumpy white cat with permanently angry/frowning face, looking extremely displeased.'
      };
    }
  });

  // src/geminiService.ts
  function validateApiKey(key) {
    return API_KEY_REGEX.test(key);
  }
  async function fetchWithTimeout(url, options, timeoutMs = 1e4) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
      return await fetch(url, { ...options, signal: controller.signal });
    } finally {
      clearTimeout(timeout);
    }
  }
  async function extractTopic(text, provider, apiKey, model) {
    const prompt = `Extract the main topic/theme from this text in 1-3 words: "${text}". Return ONLY the topic words (e.g., "choice", "failure", "confusion"). No explanation.`;
    try {
      let response;
      if (provider === "google") {
        const modelName = model.replace("models/", "");
        const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent`;
        response = await fetchWithTimeout(
          `${apiUrl}?key=${apiKey}`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              contents: [{ parts: [{ text: prompt }] }],
              generationConfig: { temperature: 0.3, topP: 0.8, topK: 20, maxOutputTokens: 10 }
            })
          },
          5e3
        );
      } else {
        response = await fetchWithTimeout(
          "https://openrouter.ai/api/v1/chat/completions",
          {
            method: "POST",
            headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
            body: JSON.stringify({
              model: model || "meta-llama/llama-3.2-3b-instruct:free",
              messages: [{ role: "user", content: prompt }],
              temperature: 0.3,
              top_p: 0.8,
              max_tokens: 10
            })
          },
          5e3
        );
      }
      if (!response.ok) return "";
      const data = await response.json();
      const topic = provider === "google" ? data.candidates?.[0]?.content?.parts?.[0]?.text?.trim().toLowerCase() : data.choices?.[0]?.message?.content?.trim().toLowerCase();
      console.log("[Chuckle] Extracted topic:", topic);
      return topic || "";
    } catch (error) {
      console.log("[Chuckle] Topic extraction failed, continuing without topic");
      return "";
    }
  }
  async function analyzeMemeContext(text, variant = 0) {
    const { offlineMode } = await chrome.storage.local.get(["offlineMode"]);
    if (offlineMode) {
      console.log("[Chuckle] Offline mode: using default template");
      return "drake";
    }
    const isRegenerate = variant > 0;
    const cacheKey = `gemini:${text}${isRegenerate ? `:v${variant}` : ""}`;
    if (!isRegenerate) {
      const cached = geminiCache.get(cacheKey);
      if (cached) {
        console.log("[Chuckle] Using cached template:", cached);
        return cached;
      }
    }
    const { aiProvider, geminiApiKey, openrouterApiKey, primaryModel, openrouterPrimaryModel } = await chrome.storage.local.get(["aiProvider", "geminiApiKey", "openrouterApiKey", "primaryModel", "openrouterPrimaryModel"]);
    const provider = aiProvider || "google";
    const model = provider === "google" ? primaryModel || "models/gemini-2.0-flash" : openrouterPrimaryModel || "meta-llama/llama-3.2-3b-instruct:free";
    console.log("[Chuckle] Calling AI API for text:", text.slice(0, 50), isRegenerate ? "(regenerate)" : "", `| Provider: ${provider} | Model: ${model}`);
    if (provider === "google") {
      if (!geminiApiKey) throw new Error(await getErrorMessage("noApiKey"));
      if (!validateApiKey(geminiApiKey)) throw new Error(await getErrorMessage("invalidApiKey"));
    } else {
      if (!openrouterApiKey) throw new Error(await getErrorMessage("noApiKey"));
    }
    const topic = !isRegenerate ? await extractTopic(text, provider, provider === "google" ? geminiApiKey : openrouterApiKey, model) : "";
    try {
      let response;
      if (provider === "google") {
        const modelName = model.replace("models/", "");
        const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent`;
        response = await fetchWithTimeout(
          `${apiUrl}?key=${geminiApiKey}`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              contents: [{
                parts: [{
                  text: isRegenerate ? `${GEMINI_PROMPT_TEMPLATE(text)}

IMPORTANT: Provide a DIFFERENT template than you might have suggested before for this text. Choose an alternative that fits the context.` : GEMINI_PROMPT_TEMPLATE(text, topic)
                }]
              }],
              generationConfig: isRegenerate ? {
                temperature: 1.3,
                topP: 0.98,
                topK: 64
              } : {
                temperature: 0.7,
                topP: 0.9,
                topK: 30
              }
            })
          },
          1e4
        );
      } else {
        response = await fetchWithTimeout(
          "https://openrouter.ai/api/v1/chat/completions",
          {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${openrouterApiKey}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              model,
              messages: [{
                role: "user",
                content: isRegenerate ? `${GEMINI_PROMPT_TEMPLATE(text)}

IMPORTANT: Provide a DIFFERENT template than you might have suggested before for this text. Choose an alternative that fits the context.` : GEMINI_PROMPT_TEMPLATE(text, topic)
              }],
              temperature: isRegenerate ? 1.3 : 0.7,
              top_p: isRegenerate ? 0.98 : 0.9
            })
          },
          1e4
        );
      }
      if (!response.ok) {
        console.error(`[Chuckle] ${provider === "google" ? "Gemini" : "OpenRouter"} API error:`, response.status);
        if (response.status === 429) {
          throw new Error(await getErrorMessage("tooManyRequests"));
        }
        if (response.status === 403 || response.status === 401) {
          throw new Error(await getErrorMessage("invalidApiKey"));
        }
        throw new Error(`API error: ${response.status}`);
      }
      const data = await response.json();
      console.log("[Chuckle] AI API response received");
      let result;
      if (provider === "google") {
        if (data.error) throw new Error(data.error.message);
        if (!data.candidates?.[0]?.content?.parts?.[0]?.text) {
          throw new Error(`Invalid API response for text: "${text.slice(0, 50)}..."`);
        }
        result = data.candidates[0].content.parts[0].text.trim().replace(/\s+/g, " ");
      } else {
        if (data.error) throw new Error(data.error.message);
        if (!data.choices?.[0]?.message?.content) {
          throw new Error(`Invalid API response for text: "${text.slice(0, 50)}..."`);
        }
        result = data.choices[0].message.content.trim().replace(/\s+/g, " ");
      }
      console.log("[Chuckle] Template from API:", result);
      if (!isRegenerate) {
        geminiCache.set(cacheKey, result);
      }
      return result;
    } catch (error) {
      const lastError = error instanceof Error ? error : new Error(String(error));
      console.error("[Chuckle] API call failed:", lastError.message);
      throw lastError;
    }
  }
  function normalizeText(text) {
    let cleaned = text.replace(/[<>"{}|\\^`\[\]]/g, "").replace(/\s+/g, "_");
    return encodeURIComponent(cleaned);
  }
  async function generateMemeImage(template, text, skipFormatting = false, forceRegenerate = false) {
    try {
      const formattedTemplate = template.trim().toLowerCase().replace(/\s+/g, "_");
      let processedText = text;
      processedText = text;
      const formattedText = skipFormatting && text.includes(" / ") ? processedText : await formatTextForTemplate(processedText, formattedTemplate, forceRegenerate);
      const cleanText2 = formattedText.replace(/['']/g, "'").replace(/…/g, "...");
      const parts = cleanText2.split(" / ").map((p) => p.trim()).filter((p) => p.length > 0);
      let topText, bottomText;
      console.log("[Chuckle] Split parts:", parts);
      console.log("[Chuckle] Parts count:", parts.length);
      if (formattedTemplate === "cmm") {
        topText = "~";
        bottomText = normalizeText(parts.join("  "));
      } else if (parts.length >= 2) {
        const bottomParts = parts.slice(1);
        const bottomJoined = bottomParts.join(" ");
        topText = normalizeText(parts[0]);
        bottomText = normalizeText(bottomJoined);
        console.log("[Chuckle] Bottom parts:", bottomParts);
        console.log("[Chuckle] Bottom joined BEFORE normalize:", bottomJoined);
        console.log("[Chuckle] Bottom text AFTER normalize:", bottomText);
      } else if (parts.length === 1 && parts[0]) {
        const words = parts[0].split(/\s+/);
        const mid = Math.ceil(words.length / 2);
        topText = normalizeText(words.slice(0, mid).join(" "));
        bottomText = normalizeText(words.slice(mid).join(" ") || "yes");
      } else {
        topText = normalizeText(cleanText2);
        bottomText = "yes";
      }
      console.log("[Chuckle] Formatted template:", formattedTemplate);
      console.log("[Chuckle] FINAL Top text:", topText);
      console.log("[Chuckle] FINAL Bottom text:", bottomText);
      let url;
      if (formattedTemplate === "cmm") {
        url = `${CONFIG.MEMEGEN_API_URL}/${formattedTemplate}/${bottomText}.png`;
      } else if (formattedTemplate === "grumpycat") {
        url = `${CONFIG.MEMEGEN_API_URL}/${formattedTemplate}/${topText}/${bottomText}.png`;
      } else {
        url = `${CONFIG.MEMEGEN_API_URL}/${formattedTemplate}/${topText}/${bottomText}.png`;
      }
      console.log("[Chuckle] FULL meme URL:", url);
      console.log("[Chuckle] Formatted text for display:", cleanText2);
      const response = await fetch(url, { method: "HEAD" });
      if (!response.ok) {
        if (response.status === 429) {
          throw new Error(await getErrorMessage("tooManyRequests"));
        }
        throw new Error("Template unavailable");
      }
      const watermarkedUrl = await addWatermark(url);
      return { watermarkedUrl, originalUrl: url, formattedText: cleanText2 };
    } catch (error) {
      logger.error("Meme image generation failed", error);
      if (error instanceof Error && (error.message.includes("429") || error.message.includes("API exhausted") || error.message.includes("API agotada") || error.message.includes("API \xE9puis\xE9e") || error.message.includes("API ersch\xF6pft") || error.message.includes("Too many requests") || error.message.includes("Too Many Requests") || error.message.includes("authentication failed") || error.message.includes("403") || error.message.includes("401"))) {
        throw error;
      }
      return { watermarkedUrl: CONFIG.FALLBACK_IMAGE_URL, originalUrl: CONFIG.FALLBACK_IMAGE_URL, formattedText: text };
    }
  }
  var init_geminiService = __esm({
    "src/geminiService.ts"() {
      "use strict";
      init_config();
      init_cache();
      init_logger2();
      init_constants();
      init_errorMessages();
      init_watermark();
      init_templateFormatter();
    }
  });

  // lib/hash.ts
  function simpleHash(str, length = 8) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = (hash << 5) - hash + str.charCodeAt(i);
      hash = hash & hash;
    }
    const hashStr = Math.abs(hash).toString(36);
    return hashStr.padEnd(length, "0").slice(0, length);
  }
  var init_hash = __esm({
    "lib/hash.ts"() {
      "use strict";
    }
  });

  // src/storage.ts
  async function saveMeme(memeData) {
    const key = `meme_${simpleHash(memeData.text + memeData.timestamp)}`;
    await chrome.storage.local.set({ [key]: memeData });
    return key;
  }
  async function getMeme(key) {
    const result = await chrome.storage.local.get(key);
    return result[key] || null;
  }
  async function getAllMemes() {
    const items = await chrome.storage.local.get(null);
    const memes = [];
    for (const [key, value] of Object.entries(items)) {
      if (key.startsWith("meme_")) {
        memes.push(value);
      }
    }
    return memes.sort((a, b) => b.timestamp - a.timestamp);
  }
  async function updateMeme(key, updates) {
    const meme = await getMeme(key);
    if (meme) {
      await chrome.storage.local.set({ [key]: { ...meme, ...updates } });
    }
  }
  var init_storage = __esm({
    "src/storage.ts"() {
      "use strict";
      init_hash();
    }
  });

  // src/undo.ts
  async function undo() {
    return false;
  }
  var init_undo = __esm({
    "src/undo.ts"() {
      "use strict";
    }
  });

  // src/shortcutConfig.ts
  async function getShortcuts() {
    const { shortcuts } = await chrome.storage.local.get("shortcuts");
    return shortcuts || DEFAULT_SHORTCUTS;
  }
  var DEFAULT_SHORTCUTS;
  var init_shortcutConfig = __esm({
    "src/shortcutConfig.ts"() {
      "use strict";
      DEFAULT_SHORTCUTS = {
        regenerate: "r",
        download: "d",
        history: "h"
      };
    }
  });

  // src/history.ts
  var history_exports = {};
  __export(history_exports, {
    applyFilters: () => applyFilters,
    createHistoryPanel: () => createHistoryPanel,
    filterRecent: () => filterRecent,
    isHistoryPanelOpen: () => isHistoryPanelOpen,
    searchHistory: () => searchHistory,
    toggleHistoryPanel: () => toggleHistoryPanel
  });
  async function createHistoryPanel() {
    if (currentPanel) {
      currentPanel.remove();
    }
    const prefs = await chrome.storage.local.get(["historyFilters"]);
    if (prefs.historyFilters) {
      recentFilterActive = prefs.historyFilters.recent || false;
    } else {
      recentFilterActive = false;
    }
    const { darkMode } = await chrome.storage.local.get(["darkMode"]);
    const isDark = darkMode !== void 0 ? darkMode : true;
    allMemes = await getAllMemes();
    const panel = document.createElement("div");
    panel.className = "history-panel";
    if (isDark) panel.classList.add("dark");
    Object.assign(panel.style, {
      position: "fixed",
      top: "20px",
      right: "20px",
      width: "300px",
      maxHeight: "80vh",
      backgroundColor: isDark ? "#1a1a2e" : "#fff",
      borderRadius: "12px",
      padding: "20px",
      boxShadow: "0 4px 20px rgba(0,0,0,0.3)",
      zIndex: "9999",
      overflow: "auto"
    });
    const header = document.createElement("div");
    Object.assign(header.style, {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: "15px"
    });
    const title = document.createElement("h3");
    title.textContent = "History";
    Object.assign(title.style, {
      margin: "0",
      fontSize: "18px",
      color: isDark ? "#fff" : "#333"
    });
    const closeBtn = document.createElement("button");
    closeBtn.className = "history-close";
    closeBtn.textContent = "\xD7";
    closeBtn.onclick = () => toggleHistoryPanel();
    Object.assign(closeBtn.style, {
      background: "none",
      border: "none",
      fontSize: "24px",
      cursor: "pointer",
      color: isDark ? "#fff" : "#333"
    });
    header.appendChild(title);
    header.appendChild(closeBtn);
    panel.appendChild(header);
    const controls = document.createElement("div");
    Object.assign(controls.style, {
      display: "flex",
      gap: "10px",
      marginBottom: "15px"
    });
    const searchInput = document.createElement("input");
    searchInput.className = "history-search";
    searchInput.type = "text";
    searchInput.placeholder = "Search memes...";
    searchInput.setAttribute("aria-label", "Search memes by text or template");
    searchInput.oninput = (e) => searchHistory(e.target.value);
    Object.assign(searchInput.style, {
      flex: "1",
      padding: "8px",
      borderRadius: "6px",
      border: `1px solid ${isDark ? "#444" : "#ddd"}`,
      backgroundColor: isDark ? "#2a2a3e" : "#fff",
      color: isDark ? "#fff" : "#333",
      fontSize: "14px"
    });
    const filterBtns = document.createElement("div");
    Object.assign(filterBtns.style, {
      display: "flex",
      gap: "6px"
    });
    const recentBtn = document.createElement("button");
    recentBtn.className = "recent-filter";
    recentBtn.textContent = "\u{1F550}";
    recentBtn.setAttribute("aria-label", "Filter recent");
    recentBtn.onclick = async () => await filterRecent();
    Object.assign(recentBtn.style, {
      padding: "8px 12px",
      borderRadius: "6px",
      border: "none",
      backgroundColor: isDark ? "#2a2a3e" : "#f5f5f5",
      cursor: "pointer",
      fontSize: "16px",
      opacity: recentFilterActive ? "1" : "0.5"
    });
    filterBtns.appendChild(recentBtn);
    controls.appendChild(searchInput);
    controls.appendChild(filterBtns);
    panel.appendChild(controls);
    const noResults = document.createElement("div");
    noResults.className = "no-results";
    noResults.textContent = "No results found";
    Object.assign(noResults.style, {
      textAlign: "center",
      color: isDark ? "#999" : "#666",
      padding: "20px",
      display: "none"
    });
    panel.appendChild(noResults);
    if (allMemes.length === 0) {
      const empty = document.createElement("div");
      empty.className = "empty-history";
      empty.textContent = "No memes yet";
      Object.assign(empty.style, {
        textAlign: "center",
        color: isDark ? "#999" : "#666",
        padding: "20px"
      });
      panel.appendChild(empty);
    } else {
      allMemes.forEach((meme) => {
        const memeId = `meme_${simpleHash(meme.text + meme.timestamp)}`;
        const item = document.createElement("div");
        item.className = "history-item";
        item.dataset.memeId = memeId;
        item.onclick = () => createOverlay(meme);
        Object.assign(item.style, {
          marginBottom: "10px",
          padding: "10px",
          borderRadius: "8px",
          cursor: "pointer",
          backgroundColor: isDark ? "#2a2a3e" : "#f5f5f5",
          transition: "transform 0.2s"
        });
        item.onmouseenter = () => item.style.transform = "scale(1.02)";
        item.onmouseleave = () => item.style.transform = "scale(1)";
        const img = document.createElement("img");
        img.src = meme.imageUrl;
        img.alt = meme.text;
        Object.assign(img.style, {
          width: "100%",
          borderRadius: "4px",
          marginBottom: "5px"
        });
        const text = document.createElement("div");
        text.className = "meme-text";
        const displayText = meme.text.length > 50 ? meme.text.slice(0, 50) + "..." : meme.text;
        text.innerHTML = displayText;
        Object.assign(text.style, {
          fontSize: "12px",
          color: isDark ? "#ccc" : "#555",
          marginBottom: "5px"
        });
        item.appendChild(img);
        item.appendChild(text);
        panel.appendChild(item);
      });
    }
    document.body.appendChild(panel);
    currentPanel = panel;
  }
  function toggleHistoryPanel() {
    if (currentPanel) {
      if (currentPanel.style.display === "none") {
        currentPanel.style.display = "block";
      } else {
        currentPanel.style.display = "none";
      }
    }
  }
  function isHistoryPanelOpen() {
    return currentPanel !== null && currentPanel.style.display !== "none";
  }
  async function applyFilters() {
    if (!currentPanel) return;
    const items = currentPanel.querySelectorAll(".history-item");
    const noResults = currentPanel.querySelector(".no-results");
    const searchInput = currentPanel.querySelector(".history-search");
    const searchQuery = searchInput?.value.toLowerCase() || "";
    await chrome.storage.local.set({
      historyFilters: {
        recent: recentFilterActive
      }
    });
    let visibleCount = 0;
    const now = Date.now();
    const dayMs = 24 * 60 * 60 * 1e3;
    items.forEach((item) => {
      const memeId = item.dataset.memeId;
      const meme = allMemes.find((m) => `meme_${simpleHash(m.text + m.timestamp)}` === memeId);
      if (!meme) return;
      const matchesSearch = searchQuery === "" || meme.text.toLowerCase().includes(searchQuery) || meme.template.toLowerCase().includes(searchQuery);
      const matchesRecent = !recentFilterActive || now - meme.timestamp < dayMs;
      if (matchesSearch && matchesRecent) {
        item.style.display = "block";
        visibleCount++;
        if (searchQuery) {
          const textEl = item.querySelector(".meme-text");
          if (textEl) {
            const originalText2 = meme.text.length > 50 ? meme.text.slice(0, 50) + "..." : meme.text;
            textEl.innerHTML = highlightText(originalText2, searchQuery);
          }
        }
      } else {
        item.style.display = "none";
      }
    });
    if (noResults) {
      noResults.style.display = visibleCount === 0 && searchQuery !== "" ? "block" : "none";
    }
  }
  async function searchHistory(_query) {
    await applyFilters();
  }
  async function filterRecent() {
    if (!currentPanel) return;
    recentFilterActive = !recentFilterActive;
    const filterBtn = currentPanel.querySelector(".recent-filter");
    if (filterBtn) {
      filterBtn.style.opacity = recentFilterActive ? "1" : "0.5";
    }
    await applyFilters();
  }
  function highlightText(text, query) {
    const regex = new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})`, "gi");
    return text.replace(regex, '<mark style="background:#ffeb3b;color:#000;padding:2px 0;">$1</mark>');
  }
  var currentPanel, allMemes, recentFilterActive;
  var init_history = __esm({
    "src/history.ts"() {
      "use strict";
      init_storage();
      init_overlay();
      currentPanel = null;
      allMemes = [];
      recentFilterActive = false;
    }
  });

  // src/shortcuts.ts
  function enableShortcuts() {
    if (shortcutsEnabled) return;
    shortcutsEnabled = true;
    document.addEventListener("keydown", handleShortcut);
  }
  function disableShortcuts() {
    shortcutsEnabled = false;
    shortcutHandlers.clear();
    actionMap.clear();
    document.removeEventListener("keydown", handleShortcut);
  }
  function registerShortcut(action, handler) {
    actionMap.set(action, action);
    shortcutHandlers.set(action, handler);
  }
  async function handleShortcut(e) {
    if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
      return;
    }
    if ((e.ctrlKey || e.metaKey) && e.key === "z") {
      e.preventDefault();
      const success = await undo();
      if (success) {
        showToast("Action undone");
      }
      return;
    }
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    const shortcuts = await getShortcuts();
    const key = e.key.toLowerCase();
    if (key === shortcuts.history) {
      e.preventDefault();
      const { createHistoryPanel: createHistoryPanel2 } = await Promise.resolve().then(() => (init_history(), history_exports));
      await createHistoryPanel2();
      return;
    }
    for (const [action, handler] of shortcutHandlers) {
      const actionKey = shortcuts[action];
      if (actionKey && key === actionKey.toLowerCase()) {
        e.preventDefault();
        await handler();
        break;
      }
    }
  }
  function showToast(message) {
    const toast = document.createElement("div");
    toast.className = "toast-notification";
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 4e3);
  }
  var shortcutsEnabled, shortcutHandlers, actionMap;
  var init_shortcuts = __esm({
    "src/shortcuts.ts"() {
      "use strict";
      init_undo();
      init_shortcutConfig();
      shortcutsEnabled = false;
      shortcutHandlers = /* @__PURE__ */ new Map();
      actionMap = /* @__PURE__ */ new Map();
    }
  });

  // src/social-share.ts
  function getTranslation(key, lang = "English") {
    const language = lang;
    return shareTranslations[language]?.[key] || shareTranslations.English[key];
  }
  async function downloadMeme(imageUrl) {
    const response = await fetch(imageUrl);
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `meme-${Date.now()}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
  function getPlatforms(lang) {
    return [
      {
        name: "Twitter",
        icon: "\u{1D54F}",
        getUrl: () => "https://twitter.com/compose/tweet"
      },
      {
        name: "LinkedIn",
        icon: "in",
        getUrl: () => "https://www.linkedin.com/feed/"
      },
      {
        name: "Email",
        icon: "\u2709\uFE0F",
        getUrl: () => "mailto:"
      }
    ];
  }
  async function trackShare(platform) {
    const key = `share_${platform.toLowerCase()}`;
    const data = await chrome.storage.local.get(key);
    await chrome.storage.local.set({ [key]: (data[key] || 0) + 1 });
  }
  function createShareModal(imageUrl, text, lang) {
    const modal = document.createElement("div");
    modal.className = "share-modal";
    modal.style.cssText = "position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.85); z-index: 2147483648; display: flex; align-items: center; justify-content: center;";
    const content = document.createElement("div");
    content.style.cssText = "background: white; border-radius: 20px; padding: 64px; max-width: 640px; position: relative; box-shadow: 0 20px 60px rgba(0,0,0,0.3);";
    const closeBtn = document.createElement("button");
    closeBtn.textContent = "\xD7";
    closeBtn.style.cssText = "position: absolute; top: 20px; right: 20px; background: transparent; border: none; width: 40px; height: 40px; font-size: 36px; cursor: pointer; color: #999; transition: color 0.2s;";
    closeBtn.onmouseover = () => closeBtn.style.color = "#333";
    closeBtn.onmouseout = () => closeBtn.style.color = "#999";
    closeBtn.onclick = () => modal.remove();
    const title = document.createElement("div");
    title.textContent = getTranslation("shareMeme", lang);
    title.style.cssText = "font-size: 24px; font-weight: 700; color: #333; margin-bottom: 16px; text-align: center;";
    const statusText = document.createElement("div");
    statusText.style.cssText = "font-size: 16px; font-weight: 700; color: #333; text-align: center; margin-bottom: 32px; min-height: 24px;";
    const buttonsContainer = document.createElement("div");
    buttonsContainer.style.cssText = "display: flex; justify-content: center; gap: 48px;";
    const platforms = getPlatforms(lang);
    const icons = {
      "Twitter": '<svg width="80" height="80" viewBox="0 0 24 24" fill="#1DA1F2"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>',
      "LinkedIn": '<svg width="80" height="80" viewBox="0 0 24 24" fill="#0A66C2"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>',
      "Email": '<svg width="80" height="80" viewBox="0 0 24 24" fill="#EA4335"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>'
    };
    platforms.forEach((platform) => {
      const btn = document.createElement("button");
      btn.innerHTML = icons[platform.name];
      btn.style.cssText = "background: transparent; border: none; cursor: pointer; padding: 20px; border-radius: 20px; transition: all 0.2s; display: flex; align-items: center; justify-content: center; min-width: 120px; min-height: 120px; flex-shrink: 0;";
      btn.onmouseover = () => {
        btn.style.transform = "scale(1.1)";
        btn.style.background = "#f5f5f5";
      };
      btn.onmouseout = () => {
        btn.style.transform = "scale(1)";
        btn.style.background = "transparent";
      };
      btn.onclick = async () => {
        const shareText = `${getTranslation("checkThisMeme", lang)} ${text}`;
        statusText.textContent = getTranslation("textCopied", lang);
        await navigator.clipboard.writeText(shareText);
        await new Promise((resolve) => setTimeout(resolve, 1e3));
        statusText.textContent = getTranslation("imageDownloaded", lang);
        await downloadMeme(imageUrl);
        await new Promise((resolve) => setTimeout(resolve, 2e3));
        window.open(platform.getUrl(imageUrl, text), "_blank");
        trackShare(platform.name);
        modal.remove();
      };
      buttonsContainer.appendChild(btn);
    });
    content.appendChild(closeBtn);
    content.appendChild(title);
    content.appendChild(statusText);
    content.appendChild(buttonsContainer);
    modal.appendChild(content);
    modal.onclick = (e) => {
      if (e.target === modal) modal.remove();
    };
    return modal;
  }
  function createShareButton(imageUrl, text, lang = "English") {
    const container = document.createElement("div");
    const btn = document.createElement("button");
    btn.className = "share-btn";
    btn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" style="display: block; pointer-events: none;"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M15.5 6.5L8.5 10.5M8.5 13.5L15.5 17.5" stroke="currentColor" stroke-width="2" fill="none"/></svg>';
    btn.setAttribute("aria-label", getTranslation("shareMeme", lang));
    btn.onclick = (e) => {
      e.stopPropagation();
      const modal = createShareModal(imageUrl, text, lang);
      document.body.appendChild(modal);
    };
    container.appendChild(btn);
    return container;
  }
  var shareTranslations;
  var init_social_share = __esm({
    "src/social-share.ts"() {
      "use strict";
      shareTranslations = {
        English: {
          shareMeme: "Share Meme",
          shareOn: "Share on",
          emailSubject: "Check out this meme!",
          download: "Download",
          regenerate: "Regenerate",
          close: "Close",
          textCopied: "Text copied!",
          imageDownloaded: "Image downloaded!",
          checkThisMeme: "Check this meme:"
        },
        Spanish: {
          shareMeme: "Compartir Meme",
          shareOn: "Compartir en",
          emailSubject: "\xA1Mira este meme!",
          download: "Descargar",
          regenerate: "Regenerar",
          close: "Cerrar",
          textCopied: "\xA1Texto copiado!",
          imageDownloaded: "\xA1Imagen descargada!",
          checkThisMeme: "Mira este meme:"
        },
        French: {
          shareMeme: "Partager Meme",
          shareOn: "Partager sur",
          emailSubject: "Regardez ce meme!",
          download: "T\xE9l\xE9charger",
          regenerate: "Reg\xE9n\xE9rer",
          close: "Fermer",
          textCopied: "Texte copi\xE9!",
          imageDownloaded: "Image t\xE9l\xE9charg\xE9e!",
          checkThisMeme: "Regardez ce meme:"
        },
        German: {
          shareMeme: "Meme Teilen",
          shareOn: "Teilen auf",
          emailSubject: "Schau dir dieses Meme an!",
          download: "Herunterladen",
          regenerate: "Regenerieren",
          close: "Schlie\xDFen",
          textCopied: "Text kopiert!",
          imageDownloaded: "Bild heruntergeladen!",
          checkThisMeme: "Schau dir dieses Meme an:"
        }
      };
    }
  });

  // src/overlay.ts
  async function loadLanguage() {
    const { selectedLanguage } = await chrome.storage.local.get(["selectedLanguage"]);
    currentLanguage = selectedLanguage || "English";
  }
  function getTranslation2(key) {
    const lang = currentLanguage;
    return overlayTranslations[lang]?.[key] || overlayTranslations.English[key];
  }
  function createButton(className, text, onClick) {
    const btn = document.createElement("button");
    btn.className = className;
    btn.textContent = text;
    btn.onclick = onClick;
    return btn;
  }
  async function downloadPng() {
    if (!currentMemeData) return;
    try {
      const response = await fetch(currentMemeData.imageUrl);
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `meme-${Date.now()}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showToast2(getTranslation2("downloaded"));
    } catch {
      showToast2(getTranslation2("downloadFailed"));
    }
  }
  function createDownloadButton() {
    const downloadBtn = createButton("star-btn", "\u2193", downloadPng);
    downloadBtn.style.fontWeight = "900";
    downloadBtn.setAttribute("aria-label", getTranslation2("downloadPng"));
    downloadBtn.setAttribute("role", "button");
    return downloadBtn;
  }
  function createCloseButton() {
    const closeBtn = createButton("close-btn", "\xD7", closeOverlay);
    closeBtn.setAttribute("aria-label", getTranslation2("closeMeme"));
    closeBtn.setAttribute("role", "button");
    return closeBtn;
  }
  async function regenerateMeme(specificTemplate) {
    if (!originalInput || isRegenerating) return;
    isRegenerating = true;
    showLoading(getTranslation2("regenerating"));
    try {
      const textToUse = isManualEdit ? originalText : originalInput;
      console.log("[Chuckle] Regenerating with text:", textToUse, "originalInput:", originalInput, "specificTemplate:", specificTemplate);
      const truncatedText = textToUse?.slice(0, 100) || "";
      const template = specificTemplate || isManualEdit && currentTemplate || await analyzeMemeContext(originalInput?.slice(0, 100) || "", Date.now());
      currentTemplate = template;
      const skipFormatting = isManualEdit;
      const forceRegenerate = !!specificTemplate;
      const { watermarkedUrl, originalUrl, formattedText } = await generateMemeImage(template, truncatedText, skipFormatting, forceRegenerate);
      isManualEdit = false;
      if (currentMemeData && currentOverlay) {
        currentMemeData.imageUrl = watermarkedUrl;
        currentMemeData.text = formattedText;
        currentMemeData.template = template;
        currentMemeData.timestamp = Date.now();
        originalImageUrl = originalUrl;
        originalText = formattedText;
        if (!isManualEdit) {
          originalInput = currentMemeData.originalInput || originalInput;
        }
        const img = currentOverlay.querySelector(".meme-image");
        if (img) {
          img.src = watermarkedUrl;
          img.setAttribute("data-template", template);
        }
        const textInput = currentOverlay.querySelector(".text-editor-input");
        if (textInput) textInput.innerText = formattedText;
        const actionsContainer = currentOverlay.querySelector(".meme-actions");
        if (actionsContainer) {
          const oldShareBtn = actionsContainer.children[1];
          const newShareBtn = createShareButton(originalUrl, formattedText, currentLanguage);
          actionsContainer.replaceChild(newShareBtn, oldShareBtn);
        }
        const templateButtons = currentOverlay.querySelectorAll(".template-btn");
        templateButtons.forEach((btn) => btn.classList.remove("active"));
        const activeBtn = currentOverlay.querySelector(`[data-template="${template}"]`);
        activeBtn?.classList.add("active");
        if (currentMemeKey) {
          await updateMeme(currentMemeKey, { imageUrl: originalUrl, originalUrl, template, timestamp: currentMemeData.timestamp, text: currentMemeData.text });
        }
      }
    } catch (error) {
      console.error("Regeneration failed:", error);
      const errorMessage = error instanceof Error ? error.message : String(error);
      showError(errorMessage);
    } finally {
      hideLoading();
      isRegenerating = false;
    }
  }
  function createMemeImage(memeData) {
    const img = document.createElement("img");
    img.className = "meme-image";
    img.src = memeData.imageUrl;
    img.alt = `Meme: ${memeData.text}`;
    img.ondblclick = () => regenerateMeme();
    img.style.cursor = "pointer";
    img.setAttribute("data-template", memeData.template);
    return img;
  }
  function createTextEditor() {
    const wrapper = document.createElement("div");
    wrapper.style.cssText = "display: flex; justify-content: center; align-items: center; padding: 8px 0; width: 100%;";
    const input = document.createElement("div");
    input.className = "text-editor-input meme-text";
    input.contentEditable = "true";
    input.setAttribute("data-placeholder", getTranslation2("textboxPlaceholder"));
    input.style.cssText = "padding: 8px 16px; border: 1px solid #dadce0; border-radius: 8px; font-size: 14px; max-width: 90vw; width: 100%; box-sizing: border-box; min-height: 40px; background: white; color: #9aa0a6;";
    setTimeout(() => {
      input.innerText = originalText || "";
      input.style.color = "black";
    }, 3e3);
    input.onblur = async () => {
      const newText = input.textContent?.trim() || "";
      if (newText && newText !== originalText) {
        originalText = newText;
        isManualEdit = true;
        await regenerateMeme();
      }
    };
    input.onkeydown = async (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        const newText = input.textContent?.trim() || "";
        if (newText) {
          originalText = newText;
          isManualEdit = true;
          await regenerateMeme();
        }
      }
    };
    wrapper.appendChild(input);
    return wrapper;
  }
  function createTemplateSelector() {
    const wrapper = document.createElement("div");
    wrapper.style.cssText = "display: flex; flex-direction: column; align-items: center; gap: 8px; padding: 16px 0 8px 0; width: 100%;";
    const templatesRow = document.createElement("div");
    templatesRow.style.cssText = "display: flex; flex-wrap: wrap; gap: 6px; justify-content: center; max-width: 90vw; width: 100%;";
    MEME_TEMPLATES.forEach((template) => {
      const btn = document.createElement("button");
      btn.className = "template-btn";
      btn.textContent = template.name;
      btn.setAttribute("data-template", template.id);
      btn.onclick = () => {
        isManualEdit = false;
        regenerateMeme(template.id);
      };
      templatesRow.appendChild(btn);
    });
    wrapper.appendChild(templatesRow);
    return wrapper;
  }
  function showToast2(message) {
    const toast = document.createElement("div");
    toast.className = "toast-notification";
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 4e3);
  }
  function showError(message) {
    console.log("[Chuckle] showError called with:", message);
    const errorDiv = document.createElement("div");
    errorDiv.className = "meme-error";
    errorDiv.textContent = message;
    errorDiv.style.cssText = "position:fixed;top:20px;right:20px;background:#c5221f;color:#fff;padding:15px 20px;border-radius:8px;z-index:2147483647;box-shadow:0 4px 12px rgba(0,0,0,0.3);font-size:14px;max-width:400px;word-wrap:break-word;";
    document.body.appendChild(errorDiv);
    console.log("[Chuckle] Error div appended to body");
    setTimeout(() => {
      errorDiv.remove();
      console.log("[Chuckle] Error div removed");
    }, 5e3);
  }
  async function createOverlay(memeData) {
    if (currentOverlay) closeOverlay();
    await loadLanguage();
    const { darkMode, offlineMode } = await chrome.storage.local.get(["darkMode", "offlineMode"]);
    const isDark = darkMode !== void 0 ? darkMode : true;
    const overlay = document.createElement("div");
    overlay.className = `meme-overlay${isDark ? " dark" : ""}`;
    overlay.setAttribute("role", "dialog");
    overlay.setAttribute("aria-modal", "true");
    const content = document.createElement("div");
    content.className = "meme-content";
    originalText = memeData.text;
    originalInput = memeData.originalInput || memeData.text;
    originalImageUrl = memeData.originalUrl || memeData.imageUrl;
    currentTemplate = memeData.template;
    currentMemeKey = `meme_${simpleHash(memeData.text + memeData.timestamp)}`;
    currentMemeData = memeData;
    content.appendChild(createTemplateSelector());
    content.appendChild(createTextEditor());
    const imgWrapper = document.createElement("div");
    imgWrapper.style.cssText = "display: flex; justify-content: center; align-items: flex-start; width: 100%; position: relative;";
    imgWrapper.appendChild(createMemeImage(memeData));
    const actionsContainer = document.createElement("div");
    actionsContainer.className = "meme-actions";
    actionsContainer.style.cssText = "position: absolute; left: 8px; top: 8px; display: flex; flex-direction: column; gap: 12px;";
    actionsContainer.appendChild(createDownloadButton());
    actionsContainer.appendChild(createShareButton(memeData.originalUrl || memeData.imageUrl, memeData.text, currentLanguage));
    actionsContainer.appendChild(createCloseButton());
    if (offlineMode) {
      const offlineIndicator = document.createElement("div");
      offlineIndicator.textContent = "\u{1F4F4}";
      offlineIndicator.style.cssText = "font-size: 20px; opacity: 0.7; margin-top: 8px;";
      actionsContainer.appendChild(offlineIndicator);
    }
    imgWrapper.appendChild(actionsContainer);
    content.appendChild(imgWrapper);
    overlay.appendChild(content);
    const currentTemplateBtn = overlay.querySelector(`[data-template="${memeData.template}"]`);
    if (currentTemplateBtn) {
      currentTemplateBtn.classList.add("active");
    }
    overlay.onclick = (e) => e.target === overlay && closeOverlay();
    content.onclick = (e) => e.stopPropagation();
    document.body.style.overflow = "hidden";
    document.body.appendChild(overlay);
    currentOverlay = overlay;
    enableShortcuts();
    registerShortcut("download", downloadPng);
    const closeButton = overlay.querySelector(".close-btn");
    closeButton?.focus();
    let escapeHandler = null;
    escapeHandler = (e) => {
      if (e.key === "Escape") {
        closeOverlay();
        if (escapeHandler) document.removeEventListener("keydown", escapeHandler);
      }
    };
    document.addEventListener("keydown", escapeHandler);
  }
  function closeOverlay() {
    if (currentOverlay) {
      currentOverlay.remove();
      currentOverlay = null;
      currentMemeKey = null;
      currentMemeData = null;
      originalText = null;
      originalInput = null;
      originalImageUrl = null;
      currentTemplate = null;
      isManualEdit = false;
      document.body.style.overflow = "";
      disableShortcuts();
    }
  }
  var overlayTranslations, currentLanguage, currentOverlay, currentMemeKey, currentMemeData, originalText, originalInput, originalImageUrl, isRegenerating, currentTemplate, isManualEdit;
  var init_overlay = __esm({
    "src/overlay.ts"() {
      "use strict";
      init_storage();
      init_shortcuts();
      init_geminiService();
      init_loading();
      init_social_share();
      init_constants();
      overlayTranslations = {
        English: {
          downloadPng: "Download",
          tryAnother: "Regenerate",
          closeMeme: "Close",
          regenerating: "\u{1F3B2} Regenerating meme...",
          regenerationFailed: "\u274C Regeneration failed",
          downloaded: "Downloaded!",
          downloadFailed: "Download failed",
          textboxTooltip: "You can change text and press Enter to update it on meme",
          templateTooltip: "Click to generate",
          textboxPlaceholder: "Change text then press Enter",
          invalidRequest: "Invalid request. Text may be too long or contain invalid characters."
        },
        Spanish: {
          downloadPng: "Descargar",
          tryAnother: "Regenerar",
          closeMeme: "Cerrar",
          regenerating: "\u{1F3B2} Regenerando meme...",
          regenerationFailed: "\u274C Regeneraci\xF3n fallida",
          downloaded: "\xA1Descargado!",
          downloadFailed: "Descarga fallida",
          textboxTooltip: "Puedes cambiar el texto y presionar Enter para actualizarlo en el meme",
          templateTooltip: "Haz clic para generar",
          textboxPlaceholder: "Cambia el texto y presiona Enter",
          invalidRequest: "Solicitud inv\xE1lida. El texto puede ser demasiado largo o contener caracteres inv\xE1lidos."
        },
        French: {
          downloadPng: "T\xE9l\xE9charger",
          tryAnother: "Reg\xE9n\xE9rer",
          closeMeme: "Fermer",
          regenerating: "\u{1F3B2} Reg\xE9n\xE9ration du meme...",
          regenerationFailed: "\u274C \xC9chec de la reg\xE9n\xE9ration",
          downloaded: "T\xE9l\xE9charg\xE9!",
          downloadFailed: "\xC9chec du t\xE9l\xE9chargement",
          textboxTooltip: "Vous pouvez modifier le texte et appuyer sur Entr\xE9e pour le mettre \xE0 jour sur le meme",
          templateTooltip: "Cliquez pour g\xE9n\xE9rer",
          textboxPlaceholder: "Modifiez le texte puis appuyez sur Entr\xE9e",
          invalidRequest: "Requ\xEAte invalide. Le texte peut \xEAtre trop long ou contenir des caract\xE8res invalides."
        },
        German: {
          downloadPng: "Herunterladen",
          tryAnother: "Regenerieren",
          closeMeme: "Schlie\xDFen",
          regenerating: "\u{1F3B2} Meme wird regeneriert...",
          regenerationFailed: "\u274C Regenerierung fehlgeschlagen",
          downloaded: "Heruntergeladen!",
          downloadFailed: "Download fehlgeschlagen",
          textboxTooltip: "Sie k\xF6nnen den Text \xE4ndern und Enter dr\xFCcken, um ihn im Meme zu aktualisieren",
          templateTooltip: "Klicken Sie zum Generieren",
          textboxPlaceholder: "Text \xE4ndern und Enter dr\xFCcken",
          invalidRequest: "Ung\xFCltige Anfrage. Text kann zu lang sein oder ung\xFCltige Zeichen enthalten."
        }
      };
      currentLanguage = "English";
      currentOverlay = null;
      currentMemeKey = null;
      currentMemeData = null;
      originalText = null;
      originalInput = null;
      originalImageUrl = null;
      isRegenerating = false;
      currentTemplate = null;
      isManualEdit = false;
    }
  });

  // src/content.ts
  init_loading();
  init_logger2();
  init_geminiService();
  init_overlay();
  init_storage();

  // src/cleanup.ts
  var MAX_AGE_DAYS = 90;
  var STORAGE_THRESHOLD = 0.8;
  var QUOTA_BYTES = 10 * 1024 * 1024;
  async function performCleanup() {
    const items = await chrome.storage.local.get(null);
    const memes = [];
    for (const [key, value] of Object.entries(items)) {
      if (key.startsWith("meme_")) {
        memes.push({ key, data: value });
      }
    }
    const now = Date.now();
    const maxAge = MAX_AGE_DAYS * 24 * 60 * 60 * 1e3;
    const toRemove = [];
    for (const { key, data } of memes) {
      if (now - data.timestamp > maxAge) {
        toRemove.push(key);
      }
    }
    const bytesInUse = await chrome.storage.local.getBytesInUse();
    if (bytesInUse > QUOTA_BYTES * STORAGE_THRESHOLD) {
      const nonFavorites = memes.filter((m) => !toRemove.includes(m.key)).sort((a, b) => a.data.timestamp - b.data.timestamp);
      let targetBytes = bytesInUse - QUOTA_BYTES * 0.6;
      for (const { key } of nonFavorites) {
        if (targetBytes <= 0) break;
        const keySize = await chrome.storage.local.getBytesInUse(key);
        toRemove.push(key);
        targetBytes -= keySize;
      }
    }
    if (toRemove.length > 0) {
      const beforeBytes = await chrome.storage.local.getBytesInUse();
      await chrome.storage.local.remove(toRemove);
      const afterBytes = await chrome.storage.local.getBytesInUse();
      return { removed: toRemove.length, freedBytes: beforeBytes - afterBytes };
    }
    return { removed: 0, freedBytes: 0 };
  }
  async function shouldCleanup() {
    const bytesInUse = await chrome.storage.local.getBytesInUse();
    return bytesInUse > QUOTA_BYTES * STORAGE_THRESHOLD;
  }

  // src/conflictDetector.ts
  var ConflictDetector = class {
    static detectConflicts() {
      const hasConflicts = this.KNOWN_CONFLICTS.some((pattern) => {
        return document.documentElement.innerHTML.includes(pattern);
      });
      if (hasConflicts) {
        console.warn("[Chuckle] Extension conflicts detected");
        this.showConflictWarning();
      }
      return hasConflicts;
    }
    static showConflictWarning() {
      const warningDiv = document.createElement("div");
      warningDiv.className = "chuckle-conflict-warning";
      warningDiv.innerHTML = `
      <div style="position:fixed;top:10px;right:10px;background:#ff9800;color:#fff;padding:12px 16px;border-radius:6px;z-index:100002;box-shadow:0 2px 8px rgba(0,0,0,0.2);font-size:13px;max-width:300px;">
        <strong>\u26A0\uFE0F Chuckle Extension Conflict</strong><br>
        Other extensions may be interfering. Try disabling other extensions temporarily.
        <button onclick="this.parentElement.parentElement.remove()" style="float:right;background:none;border:none;color:#fff;cursor:pointer;font-size:16px;margin-left:8px;">\xD7</button>
      </div>
    `;
      document.body.appendChild(warningDiv);
      setTimeout(() => warningDiv.remove(), 1e4);
    }
    static async checkExtensionHealth() {
      try {
        await chrome.storage.local.get(["test"]);
        return true;
      } catch (error) {
        console.error("[Chuckle] Extension health check failed:", error);
        return false;
      }
    }
  };
  ConflictDetector.KNOWN_CONFLICTS = [
    "chrome-extension://invalid/",
    "Could not establish connection",
    "Receiving end does not exist"
  ];

  // src/statusIndicator.ts
  var StatusIndicator = class {
    static async show() {
      const { offlineMode, geminiApiKey, openrouterApiKey, aiProvider } = await chrome.storage.local.get([
        "offlineMode",
        "geminiApiKey",
        "openrouterApiKey",
        "aiProvider"
      ]);
      const provider = aiProvider || "google";
      const hasApiKey = provider === "google" ? !!geminiApiKey : !!openrouterApiKey;
      if (offlineMode || !hasApiKey) {
        this.showOfflineIndicator();
      } else {
        this.hideIndicator();
      }
    }
    static showOfflineIndicator() {
      if (this.indicator) return;
      this.indicator = document.createElement("div");
      this.indicator.className = "chuckle-status-indicator";
      this.indicator.innerHTML = `
      <div style="position:fixed;bottom:20px;right:20px;background:#2196F3;color:#fff;padding:8px 12px;border-radius:20px;z-index:100003;box-shadow:0 2px 8px rgba(0,0,0,0.2);font-size:12px;cursor:pointer;" onclick="this.parentElement.remove()">
        \u{1F504} Chuckle: Offline Mode
      </div>
    `;
      document.body.appendChild(this.indicator);
      setTimeout(() => this.hideIndicator(), 5e3);
    }
    static hideIndicator() {
      if (this.indicator) {
        this.indicator.remove();
        this.indicator = null;
      }
    }
    static async checkApiStatus() {
      const { aiProvider, geminiApiKey, openrouterApiKey } = await chrome.storage.local.get([
        "aiProvider",
        "geminiApiKey",
        "openrouterApiKey"
      ]);
      const provider = aiProvider || "google";
      const apiKey = provider === "google" ? geminiApiKey : openrouterApiKey;
      if (!apiKey) {
        return { hasCredits: false, provider };
      }
      try {
        const testUrl = provider === "google" ? `https://generativelanguage.googleapis.com/v1beta/models?key=${apiKey}` : "https://openrouter.ai/api/v1/models";
        const response = await fetch(testUrl, {
          method: "GET",
          headers: provider === "openrouter" ? { "Authorization": `Bearer ${apiKey}` } : {}
        });
        return { hasCredits: response.ok, provider };
      } catch (error) {
        return { hasCredits: false, provider };
      }
    }
  };
  StatusIndicator.indicator = null;

  // src/content.ts
  function showError2(message) {
    try {
      const errorDiv = document.createElement("div");
      errorDiv.className = "meme-error";
      errorDiv.textContent = message;
      errorDiv.style.cssText = "position:fixed;top:20px;right:20px;background:#c5221f;color:#fff;padding:15px 20px;border-radius:8px;z-index:100001;box-shadow:0 4px 12px rgba(0,0,0,0.3);font-size:14px;max-width:400px;word-wrap:break-word;";
      if (document.body) {
        document.body.appendChild(errorDiv);
        console.log("[Chuckle] Showing error to user:", message);
        setTimeout(() => {
          try {
            if (errorDiv.parentNode) {
              errorDiv.remove();
            }
          } catch (e) {
            console.log("[Chuckle] Error cleanup failed (non-critical):", e.message);
          }
        }, 5e3);
      } else {
        console.log("[Chuckle] Cannot show error - document.body not available:", message);
      }
    } catch (error) {
      console.log("[Chuckle] Error showing error message:", error.message);
    }
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initializeChuckle);
  } else {
    initializeChuckle();
  }
  function initializeChuckle() {
    try {
      const url = window.location.href;
      const problematicDomains = [
        "chrome://",
        "chrome-extension://",
        "moz-extension://",
        "about:",
        "file://"
      ];
      if (problematicDomains.some((domain) => url.startsWith(domain))) {
        return;
      }
      console.log("[Chuckle] Extension loaded successfully \u2705");
      console.log("[Chuckle] Page URL:", window.location.href);
      ConflictDetector.detectConflicts();
      ConflictDetector.checkExtensionHealth();
      chrome.storage.local.get(["geminiApiKey", "primaryModel"], (data) => {
        console.log("[Chuckle] Storage check - API key exists:", !!data.geminiApiKey);
        console.log("[Chuckle] Storage check - Model exists:", !!data.primaryModel);
      });
    } catch (error) {
      console.log("[Chuckle] Initialization error (non-critical):", error.message);
    }
  }
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log("[Chuckle] Message received:", message.action);
    try {
      if (message.action === "generateMeme") {
        generateMeme(message.text).catch((error) => {
          console.log("[Chuckle] Meme generation error:", error.message);
        });
        sendResponse({ success: true });
      } else if (message.action === "generateMemeFromSelection") {
        const selectedText = window.getSelection()?.toString().trim();
        if (selectedText) {
          generateMeme(selectedText).catch((error) => {
            console.log("[Chuckle] Meme generation error:", error.message);
          });
        } else {
          showError2("Please select some text first");
        }
        sendResponse({ success: true });
      } else {
        sendResponse({ success: false, error: "Unknown action" });
      }
    } catch (error) {
      console.log("[Chuckle] Message handler error:", error.message);
      sendResponse({ success: false, error: error.message });
    }
    return true;
  });
  var errorMessages = {
    English: {
      storageFull: "Chrome storage full. Clear old memes in History.",
      apiKey: "API key invalid. Check settings.",
      network: "Network error. Check internet connection.",
      rateLimit: "API exhausted. Please wait a moment and try again.",
      generic: "Meme generation failed. Try again.",
      wordRange: "You must select between 6 and 30 words."
    },
    Spanish: {
      storageFull: "Almacenamiento lleno. Borra memes antiguos.",
      apiKey: "Clave API inv\xE1lida. Verifica configuraci\xF3n.",
      network: "Error de red. Verifica tu conexi\xF3n.",
      rateLimit: "API agotada. Por favor, espera un momento e int\xE9ntalo de nuevo.",
      generic: "Error al generar meme. Intenta de nuevo.",
      wordRange: "Debes seleccionar entre 6 y 30 palabras."
    },
    French: {
      storageFull: "Stockage plein. Supprimez anciens memes.",
      apiKey: "Cl\xE9 API invalide. V\xE9rifiez param\xE8tres.",
      network: "Erreur r\xE9seau. V\xE9rifiez connexion internet.",
      rateLimit: "API \xE9puis\xE9e. Veuillez attendre un moment et r\xE9essayer.",
      generic: "\xC9chec g\xE9n\xE9ration meme. R\xE9essayez.",
      wordRange: "Vous devez s\xE9lectionner entre 6 et 30 mots."
    },
    German: {
      storageFull: "Speicher voll. Alte Memes l\xF6schen.",
      apiKey: "API-Schl\xFCssel ung\xFCltig. Einstellungen pr\xFCfen.",
      network: "Netzwerkfehler. Internetverbindung pr\xFCfen.",
      rateLimit: "API ersch\xF6pft. Bitte warten Sie einen Moment und versuchen Sie es erneut.",
      generic: "Meme-Erstellung fehlgeschlagen. Erneut versuchen.",
      wordRange: "Sie m\xFCssen zwischen 6 und 30 W\xF6rter ausw\xE4hlen."
    }
  };
  async function getErrorMessage2(error) {
    const { selectedLanguage } = await chrome.storage.local.get(["selectedLanguage"]);
    const lang = selectedLanguage || "English";
    const messages = errorMessages[lang] || errorMessages.English;
    const errorStr = error instanceof Error ? error.message : String(error);
    const lowerError = errorStr.toLowerCase();
    if (lowerError.includes("quota") || lowerError.includes("quotabytes")) {
      return messages.storageFull;
    }
    if (lowerError.includes("429") || lowerError.includes("too many requests") || lowerError.includes("rate limit") || lowerError.includes("exhausted") || lowerError.includes("agotada") || lowerError.includes("\xE9puis\xE9e") || lowerError.includes("ersch\xF6pft")) {
      return messages.rateLimit;
    }
    if (lowerError.includes("403") || lowerError.includes("401") || lowerError.includes("authentication failed") || lowerError.includes("forbidden") || lowerError.includes("unauthorized")) {
      return messages.apiKey;
    }
    if (lowerError.includes("network") || lowerError.includes("fetch") || lowerError.includes("timeout") || lowerError.includes("connection")) {
      return messages.network;
    }
    if (errorStr.length > 0 && errorStr.length < 200) {
      return errorStr;
    }
    return messages.generic;
  }
  async function generateMeme(text) {
    console.log("[Chuckle] Starting meme generation for text:", text.slice(0, 50));
    await StatusIndicator.show();
    if (await shouldCleanup()) {
      const result = await performCleanup();
      if (result.removed > 0) {
        console.log(`[Chuckle] Auto-cleaned ${result.removed} memes, freed ${(result.freedBytes / 1024).toFixed(1)}KB`);
      }
    }
    const wordCount = text.trim().split(/\s+/).length;
    if (wordCount < 6 || wordCount > 30) {
      const { selectedLanguage } = await chrome.storage.local.get(["selectedLanguage"]);
      const lang = selectedLanguage || "English";
      const messages = errorMessages[lang] || errorMessages.English;
      showError2(messages.wordRange);
      return;
    }
    try {
      showLoading("Generating meme...");
      const truncatedText = text.slice(0, 1e3);
      const template = await analyzeMemeContext(truncatedText);
      console.log("[Chuckle] Template selected:", template);
      const { watermarkedUrl, originalUrl, formattedText } = await generateMemeImage(template, truncatedText);
      const memeData = {
        text: formattedText,
        imageUrl: originalUrl,
        originalUrl,
        template,
        timestamp: Date.now(),
        language: "English",
        originalInput: truncatedText
      };
      const displayData = {
        ...memeData,
        imageUrl: watermarkedUrl
      };
      await saveMeme(memeData);
      console.log("[Chuckle] Meme saved, creating overlay");
      hideLoading();
      await createOverlay(displayData);
      console.log("[Chuckle] Overlay created");
    } catch (error) {
      hideLoading();
      logger.error("Meme generation failed", error);
      const errorMsg = await getErrorMessage2(error);
      console.log("[Chuckle] Error caught in generateMeme:", error);
      console.log("[Chuckle] Error message to display:", errorMsg);
      showError2(errorMsg);
    }
  }
})();
