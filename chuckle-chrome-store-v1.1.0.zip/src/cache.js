"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.formattedCache = exports.geminiCache = void 0;
const lru_cache_1 = require("../lib/lru-cache");
exports.geminiCache = new lru_cache_1.LRUCache();
exports.formattedCache = new lru_cache_1.LRUCache(100, 3600000); // 1 hour TTL for formatted text
