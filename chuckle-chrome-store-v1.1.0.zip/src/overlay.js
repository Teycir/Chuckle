"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createOverlay = createOverlay;
exports.closeOverlay = closeOverlay;
exports.isOverlayOpen = isOverlayOpen;
const storage_1 = require("./storage");
const shortcuts_1 = require("./shortcuts");
const geminiService_1 = require("./geminiService");
const loading_1 = require("./loading");
const social_share_1 = require("./social-share");
const constants_1 = require("./constants");
const errorMessages_1 = require("./errorMessages");
const overlayTranslations = {
    English: {
        downloadPng: 'Download',
        tryAnother: 'Regenerate',
        closeMeme: 'Close',
        regenerating: '🎲 Regenerating meme...',
        regenerationFailed: '❌ Regeneration failed',
        downloaded: 'Downloaded!',
        downloadFailed: 'Download failed',
        textboxTooltip: 'You can change text and press Enter to update it on meme',
        templateTooltip: 'Click to generate',
        textboxPlaceholder: 'Change text then press Enter'
    },
    Spanish: {
        downloadPng: 'Descargar',
        tryAnother: 'Regenerar',
        closeMeme: 'Cerrar',
        regenerating: '🎲 Regenerando meme...',
        regenerationFailed: '❌ Regeneración fallida',
        downloaded: '¡Descargado!',
        downloadFailed: 'Descarga fallida',
        textboxTooltip: 'Puedes cambiar el texto y presionar Enter para actualizarlo en el meme',
        templateTooltip: 'Haz clic para generar',
        textboxPlaceholder: 'Cambia el texto y presiona Enter'
    },
    French: {
        downloadPng: 'Télécharger',
        tryAnother: 'Regénérer',
        closeMeme: 'Fermer',
        regenerating: '🎲 Regénération du meme...',
        regenerationFailed: '❌ Échec de la regénération',
        downloaded: 'Téléchargé!',
        downloadFailed: 'Échec du téléchargement',
        textboxTooltip: 'Vous pouvez modifier le texte et appuyer sur Entrée pour le mettre à jour sur le meme',
        templateTooltip: 'Cliquez pour générer',
        textboxPlaceholder: 'Modifiez le texte puis appuyez sur Entrée'
    },
    German: {
        downloadPng: 'Herunterladen',
        tryAnother: 'Regenerieren',
        closeMeme: 'Schließen',
        regenerating: '🎲 Meme wird regeneriert...',
        regenerationFailed: '❌ Regenerierung fehlgeschlagen',
        downloaded: 'Heruntergeladen!',
        downloadFailed: 'Download fehlgeschlagen',
        textboxTooltip: 'Sie können den Text ändern und Enter drücken, um ihn im Meme zu aktualisieren',
        templateTooltip: 'Klicken Sie zum Generieren',
        textboxPlaceholder: 'Text ändern und Enter drücken'
    }
};
let currentLanguage = 'English';
async function loadLanguage() {
    const { selectedLanguage } = await chrome.storage.local.get(['selectedLanguage']);
    currentLanguage = selectedLanguage || 'English';
}
function getTranslation(key) {
    const lang = currentLanguage;
    return overlayTranslations[lang]?.[key] || overlayTranslations.English[key];
}
let currentOverlay = null;
let currentMemeKey = null;
let currentMemeData = null;
let originalText = null;
let originalInput = null;
let originalImageUrl = null;
let isRegenerating = false;
let currentTemplate = null;
let isManualEdit = false;
function createButton(className, text, onClick) {
    const btn = document.createElement('button');
    btn.className = className;
    btn.textContent = text;
    btn.onclick = onClick;
    return btn;
}
async function downloadPng() {
    if (!currentMemeData)
        return;
    try {
        const response = await fetch(currentMemeData.imageUrl);
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `meme-${Date.now()}.png`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        showToast(getTranslation('downloaded'));
    }
    catch {
        showToast(getTranslation('downloadFailed'));
    }
}
function createDownloadButton() {
    const container = document.createElement('div');
    container.style.cssText = 'display: flex; flex-direction: column; align-items: center; gap: 4px;';
    const downloadBtn = createButton('star-btn', '⬇️', downloadPng);
    downloadBtn.setAttribute('aria-label', getTranslation('downloadPng'));
    downloadBtn.setAttribute('role', 'button');
    const label = document.createElement('div');
    label.textContent = getTranslation('downloadPng');
    label.style.cssText = 'font-size: 10px; color: #5f6368; font-weight: 500;';
    container.appendChild(downloadBtn);
    container.appendChild(label);
    return container;
}
function createCloseButton() {
    const container = document.createElement('div');
    container.style.cssText = 'display: flex; flex-direction: column; align-items: center; gap: 4px;';
    const closeBtn = createButton('close-btn', '×', closeOverlay);
    closeBtn.setAttribute('aria-label', getTranslation('closeMeme'));
    closeBtn.setAttribute('role', 'button');
    const label = document.createElement('div');
    label.textContent = getTranslation('closeMeme');
    label.style.cssText = 'font-size: 10px; color: #5f6368; font-weight: 500;';
    container.appendChild(closeBtn);
    container.appendChild(label);
    return container;
}
async function regenerateMeme(specificTemplate) {
    if (!originalInput || isRegenerating)
        return;
    isRegenerating = true;
    (0, loading_1.showLoading)(getTranslation('regenerating'));
    try {
        const textToUse = isManualEdit ? originalText : originalInput;
        console.log('[Chuckle] Regenerating with text:', textToUse, 'originalInput:', originalInput, 'specificTemplate:', specificTemplate);
        const truncatedText = textToUse?.slice(0, 100) || '';
        const template = specificTemplate || currentTemplate || await (0, geminiService_1.analyzeMemeContext)(truncatedText, Date.now());
        currentTemplate = template;
        const skipFormatting = isManualEdit;
        const { watermarkedUrl, originalUrl, formattedText } = await (0, geminiService_1.generateMemeImage)(template, truncatedText, skipFormatting);
        isManualEdit = false;
        if (currentMemeData && currentOverlay) {
            currentMemeData.imageUrl = watermarkedUrl;
            currentMemeData.text = formattedText;
            currentMemeData.template = template;
            currentMemeData.timestamp = Date.now();
            originalImageUrl = originalUrl;
            originalText = formattedText;
            if (!isManualEdit) {
                originalInput = currentMemeData.originalInput || originalInput;
            }
            const img = currentOverlay.querySelector('.meme-image');
            if (img)
                img.src = watermarkedUrl;
            const textInput = currentOverlay.querySelector('.text-editor-input');
            if (textInput)
                textInput.innerText = formattedText;
            const actionsContainer = currentOverlay.querySelector('.meme-actions');
            if (actionsContainer) {
                const oldShareBtn = actionsContainer.children[1];
                const newShareBtn = (0, social_share_1.createShareButton)(originalUrl, formattedText, currentLanguage);
                actionsContainer.replaceChild(newShareBtn, oldShareBtn);
            }
            const templateButtons = currentOverlay.querySelectorAll('.template-btn');
            templateButtons.forEach(btn => btn.classList.remove('active'));
            const activeBtn = currentOverlay.querySelector(`[data-template="${template}"]`);
            activeBtn?.classList.add('active');
            if (currentMemeKey) {
                await (0, storage_1.updateMeme)(currentMemeKey, { imageUrl: originalUrl, originalUrl, template, timestamp: currentMemeData.timestamp, text: currentMemeData.text });
            }
        }
    }
    catch (error) {
        console.error('Regeneration failed:', error);
        let errorMessage;
        if (error instanceof Error) {
            const rateLimitMessage = await (0, errorMessages_1.getErrorMessage)('tooManyRequests');
            if (error.message.includes(rateLimitMessage) || error.message.includes('API exhausted') || error.message.includes('429')) {
                errorMessage = rateLimitMessage;
            }
            else if (error.message.includes('Failed to format text')) {
                const match = error.message.match(/Error: (.+)$/);
                errorMessage = match ? match[1] : error.message;
            }
            else {
                errorMessage = error.message;
            }
        }
        else {
            errorMessage = await (0, errorMessages_1.getErrorMessage)('generationFailed');
        }
        showError(errorMessage);
    }
    finally {
        (0, loading_1.hideLoading)();
        isRegenerating = false;
    }
}
function createMemeImage(memeData) {
    const img = document.createElement('img');
    img.className = 'meme-image';
    img.src = memeData.imageUrl;
    img.alt = `Meme: ${memeData.text}`;
    img.ondblclick = () => regenerateMeme();
    img.style.cursor = 'pointer';
    return img;
}
function createTextEditor() {
    const wrapper = document.createElement('div');
    wrapper.style.cssText = 'display: flex; justify-content: center; align-items: center; padding: 8px 0; width: 100%;';
    const input = document.createElement('div');
    input.className = 'text-editor-input meme-text';
    input.contentEditable = 'true';
    input.setAttribute('data-placeholder', getTranslation('textboxPlaceholder'));
    input.style.cssText = 'padding: 8px 16px; border: 1px solid #dadce0; border-radius: 8px; font-size: 14px; max-width: 90vw; width: 100%; box-sizing: border-box; min-height: 40px; background: white; color: #9aa0a6;';
    setTimeout(() => {
        input.innerText = originalText || '';
        input.style.color = 'black';
    }, 3000);
    input.onblur = async () => {
        const newText = input.textContent?.trim() || '';
        if (newText && newText !== originalText) {
            originalText = newText;
            isManualEdit = true;
            await regenerateMeme();
        }
    };
    input.onkeydown = async (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            const newText = input.textContent?.trim() || '';
            if (newText) {
                originalText = newText;
                isManualEdit = true;
                await regenerateMeme();
            }
        }
    };
    wrapper.appendChild(input);
    return wrapper;
}
function createTemplateSelector() {
    const wrapper = document.createElement('div');
    wrapper.style.cssText = 'display: flex; flex-direction: column; align-items: center; gap: 8px; padding: 16px 0 8px 0; width: 100%;';
    const templatesRow = document.createElement('div');
    templatesRow.style.cssText = 'display: flex; flex-wrap: wrap; gap: 6px; justify-content: center; max-width: 90vw; width: 100%;';
    constants_1.MEME_TEMPLATES.forEach((template) => {
        const btn = document.createElement('button');
        btn.className = 'template-btn';
        btn.textContent = template.name;
        btn.setAttribute('data-template', template.id);
        btn.onclick = () => {
            isManualEdit = false;
            regenerateMeme(template.id);
        };
        templatesRow.appendChild(btn);
    });
    wrapper.appendChild(templatesRow);
    return wrapper;
}
function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast-notification';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}
function showError(message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'meme-error';
    errorDiv.textContent = message;
    errorDiv.style.cssText = 'position:fixed;top:20px;right:20px;background:#c5221f;color:#fff;padding:15px 20px;border-radius:8px;z-index:10001;box-shadow:0 4px 12px rgba(0,0,0,0.3)';
    document.body.appendChild(errorDiv);
    setTimeout(() => errorDiv.remove(), 5000);
}
async function createOverlay(memeData) {
    if (currentOverlay)
        closeOverlay();
    await loadLanguage();
    const { darkMode } = await chrome.storage.local.get(['darkMode']);
    const overlay = document.createElement('div');
    overlay.className = `meme-overlay${darkMode ? ' dark' : ''}`;
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    const content = document.createElement('div');
    content.className = 'meme-content';
    originalText = memeData.text;
    originalInput = memeData.originalInput || memeData.text;
    originalImageUrl = memeData.originalUrl || memeData.imageUrl;
    currentTemplate = memeData.template;
    currentMemeKey = `meme_${(0, storage_1.simpleHash)(memeData.text + memeData.timestamp)}`;
    currentMemeData = memeData;
    content.appendChild(createTemplateSelector());
    content.appendChild(createTextEditor());
    const imgWrapper = document.createElement('div');
    imgWrapper.style.cssText = 'display: flex; justify-content: center; align-items: flex-start; width: 100%; position: relative;';
    imgWrapper.appendChild(createMemeImage(memeData));
    const actionsContainer = document.createElement('div');
    actionsContainer.className = 'meme-actions';
    actionsContainer.style.cssText = 'position: absolute; left: 8px; top: 8px; display: flex; flex-direction: column; gap: 12px;';
    actionsContainer.appendChild(createDownloadButton());
    actionsContainer.appendChild((0, social_share_1.createShareButton)(memeData.originalUrl || memeData.imageUrl, memeData.text, currentLanguage));
    actionsContainer.appendChild(createCloseButton());
    imgWrapper.appendChild(actionsContainer);
    content.appendChild(imgWrapper);
    overlay.appendChild(content);
    const currentTemplateBtn = overlay.querySelector(`[data-template="${memeData.template}"]`);
    if (currentTemplateBtn) {
        currentTemplateBtn.classList.add('active');
    }
    overlay.onclick = (e) => e.target === overlay && closeOverlay();
    content.onclick = (e) => e.stopPropagation();
    document.body.style.overflow = 'hidden';
    document.body.appendChild(overlay);
    currentOverlay = overlay;
    (0, shortcuts_1.enableShortcuts)();
    (0, shortcuts_1.registerShortcut)('download', downloadPng);
    const closeButton = overlay.querySelector('.close-btn');
    closeButton?.focus();
    let escapeHandler = null;
    escapeHandler = (e) => {
        if (e.key === 'Escape') {
            closeOverlay();
            if (escapeHandler)
                document.removeEventListener('keydown', escapeHandler);
        }
    };
    document.addEventListener('keydown', escapeHandler);
}
function closeOverlay() {
    if (currentOverlay) {
        currentOverlay.remove();
        currentOverlay = null;
        currentMemeKey = null;
        currentMemeData = null;
        originalText = null;
        originalInput = null;
        originalImageUrl = null;
        currentTemplate = null;
        isManualEdit = false;
        document.body.style.overflow = '';
        (0, shortcuts_1.disableShortcuts)();
    }
}
function isOverlayOpen() {
    return currentOverlay !== null && document.body.contains(currentOverlay);
}
