"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MEME_TEMPLATES = void 0;
exports.getRandomTemplate = getRandomTemplate;
exports.MEME_TEMPLATES = [
    'Distracted Boyfriend',
    'Drake Hotline Bling',
    'Two Buttons',
    'Change My Mind',
    'Expanding Brain',
    'Is This A Pigeon',
    'Woman Yelling At Cat',
    'Bernie Sanders',
    'Surprised Pikachu',
    'This Is Fine',
    'Galaxy Brain',
    'Stonks',
    'Always Has Been',
    'Buff Doge vs Cheems',
    'Wojak',
    'Pepe The Frog',
    'Success Kid',
    'Bad Luck Brian',
    'One Does Not Simply',
    'Ancient Aliens'
];
function getRandomTemplate() {
    return exports.MEME_TEMPLATES[Math.floor(Math.random() * exports.MEME_TEMPLATES.length)];
}
