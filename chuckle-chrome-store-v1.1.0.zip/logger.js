"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = void 0;
const logger_1 = require("../lib/logger");
const DEBUG = false; // Set to true for production debugging
exports.logger = new logger_1.Logger('Chuckle', DEBUG);
