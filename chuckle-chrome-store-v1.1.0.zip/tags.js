"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addTag = addTag;
exports.removeTag = removeTag;
exports.getAllTags = getAllTags;
exports.filterTags = filterTags;
const storage_1 = require("./storage");
async function addTag(memeKey, tag) {
    const trimmedTag = tag.trim();
    if (!trimmedTag)
        return;
    const meme = await (0, storage_1.getMeme)(memeKey);
    if (!meme) {
        console.warn(`Cannot add tag: meme ${memeKey} not found`);
        return;
    }
    if (!meme.tags.includes(trimmedTag)) {
        meme.tags.push(trimmedTag);
        await (0, storage_1.updateMeme)(memeKey, { tags: meme.tags });
    }
}
async function removeTag(memeKey, tag) {
    const meme = await (0, storage_1.getMeme)(memeKey);
    if (!meme) {
        console.warn(`Cannot remove tag: meme ${memeKey} not found`);
        return;
    }
    const updatedTags = meme.tags.filter(t => t !== tag);
    await (0, storage_1.updateMeme)(memeKey, { tags: updatedTags });
}
async function getAllTags() {
    const memes = await (0, storage_1.getAllMemes)();
    const tagCount = new Map();
    memes.forEach(meme => {
        meme.tags.forEach(tag => tagCount.set(tag, (tagCount.get(tag) || 0) + 1));
    });
    return Array.from(tagCount.entries())
        .sort((a, b) => b[1] - a[1])
        .map(([tag]) => tag);
}
function filterTags(tags, query) {
    const lowerQuery = query.toLowerCase().trim();
    if (!lowerQuery)
        return [];
    return tags.filter(tag => tag.toLowerCase().includes(lowerQuery));
}
