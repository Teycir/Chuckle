"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_SHORTCUTS = void 0;
exports.getShortcuts = getShortcuts;
exports.saveShortcuts = saveShortcuts;
exports.validateShortcut = validateShortcut;
exports.hasConflict = hasConflict;
exports.DEFAULT_SHORTCUTS = {
    regenerate: 'r',
    download: 'd',
    history: 'h'
};
const RESERVED_KEYS = ['escape', 'enter', 'tab', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright'];
async function getShortcuts() {
    const { shortcuts } = await chrome.storage.local.get('shortcuts');
    return shortcuts || exports.DEFAULT_SHORTCUTS;
}
async function saveShortcuts(shortcuts) {
    await chrome.storage.local.set({ shortcuts });
}
function validateShortcut(key) {
    return key.length === 1 && !RESERVED_KEYS.includes(key.toLowerCase());
}
function hasConflict(shortcuts, key, exclude) {
    return Object.entries(shortcuts).some(([action, shortcut]) => action !== exclude && shortcut.toLowerCase() === key.toLowerCase());
}
