"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.simpleHash = void 0;
exports.saveMeme = saveMeme;
exports.getMeme = getMeme;
exports.getAllMemes = getAllMemes;
exports.removeMeme = removeMeme;
exports.updateMeme = updateMeme;
const hash_1 = require("../lib/hash");
Object.defineProperty(exports, "simpleHash", { enumerable: true, get: function () { return hash_1.simpleHash; } });
async function saveMeme(memeData) {
    const key = `meme_${(0, hash_1.simpleHash)(memeData.text + memeData.timestamp)}`;
    await chrome.storage.local.set({ [key]: memeData });
    return key;
}
async function getMeme(key) {
    const result = await chrome.storage.local.get(key);
    return result[key] || null;
}
async function getAllMemes() {
    const items = await chrome.storage.local.get(null);
    const memes = [];
    for (const [key, value] of Object.entries(items)) {
        if (key.startsWith('meme_')) {
            memes.push(value);
        }
    }
    return memes.sort((a, b) => b.timestamp - a.timestamp);
}
async function removeMeme(key) {
    await chrome.storage.local.remove(key);
}
async function updateMeme(key, updates) {
    const meme = await getMeme(key);
    if (meme) {
        await chrome.storage.local.set({ [key]: { ...meme, ...updates } });
    }
}
