"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.showLoading = showLoading;
exports.hideLoading = hideLoading;
let loadingOverlay = null;
function showLoading(message = 'Generating meme...') {
    if (loadingOverlay)
        return;
    loadingOverlay = document.createElement('div');
    loadingOverlay.className = 'loading-overlay';
    const spinner = document.createElement('div');
    spinner.className = 'loading-spinner';
    const text = document.createElement('div');
    text.className = 'loading-text';
    text.textContent = message;
    loadingOverlay.appendChild(spinner);
    loadingOverlay.appendChild(text);
    document.body.appendChild(loadingOverlay);
}
function hideLoading() {
    if (loadingOverlay) {
        loadingOverlay.remove();
        loadingOverlay = null;
    }
}
