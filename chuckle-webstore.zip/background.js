"use strict";
(() => {
  // src/cleanup.ts
  var MAX_AGE_DAYS = 90;
  var STORAGE_THRESHOLD = 0.8;
  var QUOTA_BYTES = 10 * 1024 * 1024;
  async function performCleanup() {
    const items = await chrome.storage.local.get(null);
    const memes = [];
    for (const [key, value] of Object.entries(items)) {
      if (key.startsWith("meme_")) {
        memes.push({ key, data: value });
      }
    }
    const now = Date.now();
    const maxAge = MAX_AGE_DAYS * 24 * 60 * 60 * 1e3;
    const toRemove = [];
    for (const { key, data } of memes) {
      if (now - data.timestamp > maxAge) {
        toRemove.push(key);
      }
    }
    const bytesInUse = await chrome.storage.local.getBytesInUse();
    if (bytesInUse > QUOTA_BYTES * STORAGE_THRESHOLD) {
      const nonFavorites = memes.filter((m) => !toRemove.includes(m.key)).sort((a, b) => a.data.timestamp - b.data.timestamp);
      let targetBytes = bytesInUse - QUOTA_BYTES * 0.6;
      for (const { key } of nonFavorites) {
        if (targetBytes <= 0) break;
        const keySize = await chrome.storage.local.getBytesInUse(key);
        toRemove.push(key);
        targetBytes -= keySize;
      }
    }
    if (toRemove.length > 0) {
      const beforeBytes = await chrome.storage.local.getBytesInUse();
      await chrome.storage.local.remove(toRemove);
      const afterBytes = await chrome.storage.local.getBytesInUse();
      return { removed: toRemove.length, freedBytes: beforeBytes - afterBytes };
    }
    return { removed: 0, freedBytes: 0 };
  }

  // src/background.ts
  chrome.runtime.onInstalled.addListener(() => {
    console.log("[Chuckle] Background script loaded \u2705");
    try {
      chrome.contextMenus.create({
        id: "remixAsMeme",
        title: "Remix as a Meme",
        contexts: ["selection"]
      });
      console.log("[Chuckle] Context menu created \u2705");
      chrome.alarms.create("weeklyCleanup", { periodInMinutes: 10080 });
      console.log("[Chuckle] Cleanup alarm scheduled \u2705");
    } catch (error) {
      console.log("[Chuckle] Setup error:", error instanceof Error ? error.message : String(error));
    }
  });
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "weeklyCleanup") {
      performCleanup().then((result) => {
        if (result.removed > 0) {
          console.log(`[Chuckle] Cleaned ${result.removed} old memes, freed ${(result.freedBytes / 1024).toFixed(1)}KB`);
        }
      });
    }
  });
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === "remixAsMeme" && info.selectionText && tab?.id) {
      console.log("[Chuckle] Context menu clicked, text:", info.selectionText.slice(0, 50));
      chrome.tabs.sendMessage(tab.id, {
        action: "generateMeme",
        text: info.selectionText
      }).catch((error) => {
        console.log("[Chuckle] Message send failed (tab may be closed):", error instanceof Error ? error.message : String(error));
      });
    }
  });
  chrome.commands.onCommand.addListener((command) => {
    console.log("[Chuckle] Keyboard shortcut triggered:", command);
    if (command === "generate-meme") {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]?.id) {
          chrome.tabs.sendMessage(tabs[0].id, { action: "generateMemeFromSelection" }).catch((error) => {
            console.log("[Chuckle] Message send failed (content script may not be ready):", error instanceof Error ? error.message : String(error));
          });
        }
      });
    }
  });
  chrome.action.onClicked.addListener(() => {
    chrome.tabs.create({ url: chrome.runtime.getURL("popup.html") });
  });
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    try {
      if (message.action === "openPopup") {
        chrome.tabs.create({ url: chrome.runtime.getURL("popup.html") });
        sendResponse({ success: true });
      } else if (message.action === "openTab") {
        chrome.tabs.create({ url: message.url });
        sendResponse({ success: true });
      } else {
        sendResponse({ success: false, error: "Unknown action" });
      }
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error);
      console.log("[Chuckle] Background message error:", errorMsg);
      sendResponse({ success: false, error: errorMsg });
    }
    return true;
  });
})();
