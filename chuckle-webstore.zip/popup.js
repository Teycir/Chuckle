"use strict";
(() => {
  // src/constants.ts
  var MEME_TEMPLATES = [
    { id: "drake", name: "Drake", topics: ["choice", "preference", "comparison", "rejection", "approval"] },
    { id: "db", name: "Distracted BF", topics: ["temptation", "distraction", "betrayal", "choice", "infidelity"] },
    { id: "ds", name: "Daily Struggle", topics: ["impossible choice", "dilemma", "absurd", "stress", "panic"] },
    { id: "cmm", name: "Change My Mind", topics: ["opinion", "debate", "controversial", "statement", "challenge"] },
    { id: "pigeon", name: "Pigeon", topics: ["confusion", "misunderstanding", "wrong", "mistake", "identification"] },
    { id: "woman-cat", name: "Woman Cat", topics: ["argument", "accusation", "defense", "dismissal", "conflict"] },
    { id: "fine", name: "This Is Fine", topics: ["denial", "disaster", "chaos", "cope", "fire"] },
    { id: "stonks", name: "Stonks", topics: ["success", "profit", "unexpected", "win", "growth"] },
    { id: "success", name: "Success Kid", topics: ["victory", "achievement", "win", "triumph", "celebration"] },
    { id: "blb", name: "Bad Luck Brian", topics: ["failure", "misfortune", "unlucky", "disaster", "backfire"] },
    { id: "fry", name: "Futurama Fry", topics: ["suspicion", "doubt", "uncertain", "paranoid", "question"] },
    { id: "fwp", name: "First World", topics: ["privilege", "complaint", "minor", "luxury", "trivial"] },
    { id: "doge", name: "Doge", topics: ["excitement", "enthusiasm", "wow", "much", "very"] },
    { id: "iw", name: "Insanity Wolf", topics: ["extreme", "crazy", "overreaction", "insane", "wild"] },
    { id: "philosoraptor", name: "Philosoraptor", topics: ["philosophy", "deep", "thinking", "paradox", "question"] },
    { id: "grumpycat", name: "Grumpy Cat", topics: ["grumpy", "rejection", "no", "refusal", "negative"] }
  ];

  // src/analytics.ts
  async function getAnalytics() {
    const data = await chrome.storage.local.get(null);
    const memes = Object.entries(data).filter(([k]) => k.startsWith("meme_")).map(([, v]) => v);
    const templates = {};
    memes.forEach((meme) => {
      templates[meme.template] = (templates[meme.template] || 0) + 1;
    });
    const topTemplates = Object.entries(templates).sort(([, a], [, b]) => b - a).slice(0, 5).map(([id, count]) => {
      const template = MEME_TEMPLATES.find((t) => t.id === id);
      return { name: template?.name || id, count };
    });
    return {
      totalMemes: memes.length,
      topTemplates,
      shareStats: {
        twitter: data.share_twitter || 0,
        reddit: data.share_reddit || 0,
        linkedin: data.share_linkedin || 0,
        email: data.share_email || 0
      }
    };
  }
  async function exportData() {
    const data = await chrome.storage.local.get(null);
    const memes = Object.entries(data).filter(([k]) => k.startsWith("meme_")).map(([k, v]) => ({ key: k, ...v }));
    const csv = [
      "Key,Template,Text,Image URL,Timestamp,Language",
      ...memes.map((m) => `${m.key},"${m.template}","${m.text.replace(/"/g, '""')}",${m.imageUrl},${m.timestamp},${m.language}`)
    ].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `chuckle-memes-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  // src/modelValidator.ts
  async function validateModelForMemeGeneration(apiKey, model, provider) {
    try {
      const testPrompt = 'Convert "test message" to meme format. Return exactly: "top text / bottom text"';
      let response;
      if (provider === "google") {
        const modelName = model.replace("models/", "");
        const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent`;
        response = await fetch(`${apiUrl}?key=${apiKey}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{ parts: [{ text: testPrompt }] }],
            generationConfig: { temperature: 0.1, maxOutputTokens: 50 }
          })
        });
      } else {
        response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
          method: "POST",
          headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
          body: JSON.stringify({
            model,
            messages: [{ role: "user", content: testPrompt }],
            temperature: 0.1,
            max_tokens: 50
          })
        });
      }
      if (!response.ok) return false;
      const data = await response.json();
      const text = provider === "google" ? data.candidates?.[0]?.content?.parts?.[0]?.text : data.choices?.[0]?.message?.content;
      return !!(text && text.trim().length > 0 && text.includes("/"));
    } catch (error) {
      return false;
    }
  }
  async function validateAndSetupModels(apiKey, provider, statusCallback) {
    statusCallback?.("Testing models...", "loading");
    const testModels = provider === "google" ? ["models/gemini-2.5-flash"] : ["meta-llama/llama-3.3-70b-instruct:free", "qwen/qwen-2.5-72b-instruct:free", "meta-llama/llama-3.2-3b-instruct:free"];
    const validModels = [];
    for (const model of testModels) {
      try {
        console.log(`[Chuckle] Testing ${provider} model:`, model);
        const isValid = await validateModelForMemeGeneration(apiKey, model, provider);
        if (isValid) {
          validModels.push(model);
          console.log(`[Chuckle] \u2705 Valid ${provider} model:`, model);
        } else {
          console.log(`[Chuckle] \u274C Invalid ${provider} model:`, model);
        }
      } catch (error) {
        console.log(`[Chuckle] \u274C Error testing ${provider}`, model, error);
      }
    }
    if (validModels.length === 0) {
      statusCallback?.("No working models found", "error");
      return false;
    }
    const primary = validModels[0];
    const fallbacks = validModels.slice(1);
    const storageKey = provider === "google" ? "primaryModel" : "openrouterPrimaryModel";
    const fallbackKey = provider === "google" ? "fallbackModels" : "openrouterFallbackModels";
    await chrome.storage.local.set({
      [storageKey]: primary,
      [fallbackKey]: fallbacks
    });
    console.log(`[Chuckle] \u2705 ${provider} model cascade setup:`, { primary, fallbacks });
    const modelName = primary.split("/").pop();
    statusCallback?.(`Using ${modelName} (+${fallbacks.length} fallbacks)`, "success");
    return true;
  }

  // src/popup.ts
  var elements = null;
  function getElements() {
    if (!elements) {
      elements = {
        providerSelect: document.getElementById("providerSelect"),
        geminiApiKey: document.getElementById("geminiApiKey"),
        openrouterApiKey: document.getElementById("openrouterApiKey"),
        languageSelect: document.getElementById("languageSelect"),
        darkMode: document.getElementById("darkMode"),
        statusMsg: document.getElementById("statusMsg")
      };
    }
    return elements;
  }
  function updateModelLabel(labelId, modelName) {
    const label = document.getElementById(labelId);
    if (label && modelName) {
      const displayName = modelName.split("/").pop() || modelName;
      label.textContent = `\u{1F916} ${displayName}`;
      label.style.color = "#137333";
      label.style.background = "#e6f4ea";
    }
  }
  var translations = {
    English: {
      title: "\u{1F3AD} Chuckle Settings",
      providerLabel: "\u{1F510} AI Provider",
      apiKeyLabel: "\u{1F511} Gemini API Key",
      apiHelp: "Get key from",
      openrouterKeyLabel: "\u{1F511} OpenRouter Key",
      languageLabel: "\u{1F310} Language",
      darkModeLabel: "\u{1F319} Dark Mode",
      offlineModeLabel: "\u{1F4F4} Offline Mode",
      saveButton: "\u{1F4BE} Save Settings",
      saved: "Saved!",
      getKeyInfo: "Get key from",
      howToUse: "How to use: Highlight text \u2192 Right-click \u2192 Remix as a Meme",
      madeBy: "Meme generator, made by",
      settingsTab: "\u2699\uFE0F Settings",
      statsTab: "\u{1F4CA} Stats",
      statsTitle: "\u{1F4CA} Your Meme Stats",
      totalMemes: "Total Memes",
      topTemplates: "\u{1F3C6} Top Templates",
      sharesLabel: "\u{1F4E4} Shares",
      exportData: "\u{1F4E5} Export Data",
      invalidKeyFormat: "Invalid API key format",
      cannotLoadModels: "Cannot load models - API key may be invalid",
      noModelsFound: "No compatible models found"
    },
    Spanish: {
      title: "\u{1F3AD} Configuraci\xF3n de Chuckle",
      providerLabel: "\u{1F510} Proveedor de IA",
      apiKeyLabel: "\u{1F511} Clave API de Gemini",
      apiHelp: "Obtener clave de",
      openrouterKeyLabel: "\u{1F511} Clave OpenRouter",
      languageLabel: "\u{1F310} Idioma",
      darkModeLabel: "\u{1F319} Modo Oscuro",
      offlineModeLabel: "\u{1F4F4} Modo Sin Conexi\xF3n",
      saveButton: "\u{1F4BE} Guardar Configuraci\xF3n",
      saved: "\xA1Guardado!",
      getKeyInfo: "Obtener clave de",
      howToUse: "C\xF3mo usar: Resaltar texto \u2192 Clic derecho \u2192 Remix as a Meme",
      madeBy: "Generador de memes, hecho por",
      settingsTab: "\u2699\uFE0F Configuraci\xF3n",
      statsTab: "\u{1F4CA} Estad\xEDsticas",
      statsTitle: "\u{1F4CA} Tus Estad\xEDsticas",
      totalMemes: "Memes Totales",
      topTemplates: "\u{1F3C6} Mejores Plantillas",
      sharesLabel: "\u{1F4E4} Compartidos",
      exportData: "\u{1F4E5} Exportar Datos",
      invalidKeyFormat: "Formato de clave API inv\xE1lido",
      cannotLoadModels: "No se pueden cargar modelos - la clave API puede ser inv\xE1lida",
      noModelsFound: "No se encontraron modelos compatibles"
    },
    French: {
      title: "\u{1F3AD} Param\xE8tres Chuckle",
      providerLabel: "\u{1F510} Fournisseur IA",
      apiKeyLabel: "\u{1F511} Cl\xE9 API Gemini",
      apiHelp: "Obtenir la cl\xE9 de",
      openrouterKeyLabel: "\u{1F511} Cl\xE9 OpenRouter",
      languageLabel: "\u{1F310} Langue",
      darkModeLabel: "\u{1F319} Mode Sombre",
      offlineModeLabel: "\u{1F4F4} Mode Hors Ligne",
      saveButton: "\u{1F4BE} Enregistrer",
      saved: "Enregistr\xE9!",
      getKeyInfo: "Obtenir la cl\xE9 de",
      howToUse: "Comment utiliser: Surligner le texte \u2192 Clic droit \u2192 Remix as a Meme",
      madeBy: "G\xE9n\xE9rateur de m\xE8mes, cr\xE9\xE9 par",
      settingsTab: "\u2699\uFE0F Param\xE8tres",
      statsTab: "\u{1F4CA} Statistiques",
      statsTitle: "\u{1F4CA} Vos Statistiques",
      totalMemes: "Memes Totaux",
      topTemplates: "\u{1F3C6} Meilleurs Mod\xE8les",
      sharesLabel: "\u{1F4E4} Partages",
      exportData: "\u{1F4E5} Exporter les Donn\xE9es",
      invalidKeyFormat: "Format de cl\xE9 API invalide",
      cannotLoadModels: "Impossible de charger les mod\xE8les - la cl\xE9 API peut \xEAtre invalide",
      noModelsFound: "Aucun mod\xE8le compatible trouv\xE9"
    },
    German: {
      title: "\u{1F3AD} Chuckle Einstellungen",
      providerLabel: "\u{1F510} KI-Anbieter",
      apiKeyLabel: "\u{1F511} Gemini API-Schl\xFCssel",
      apiHelp: "Schl\xFCssel erhalten von",
      openrouterKeyLabel: "\u{1F511} OpenRouter-Schl\xFCssel",
      languageLabel: "\u{1F310} Sprache",
      darkModeLabel: "\u{1F319} Dunkler Modus",
      offlineModeLabel: "\u{1F4F4} Offline-Modus",
      saveButton: "\u{1F4BE} Speichern",
      saved: "Gespeichert!",
      getKeyInfo: "Schl\xFCssel erhalten von",
      howToUse: "Verwendung: Text markieren \u2192 Rechtsklick \u2192 Remix as a Meme",
      madeBy: "Meme-Generator, erstellt von",
      settingsTab: "\u2699\uFE0F Einstellungen",
      statsTab: "\u{1F4CA} Statistiken",
      statsTitle: "\u{1F4CA} Ihre Statistiken",
      totalMemes: "Memes Gesamt",
      topTemplates: "\u{1F3C6} Top-Vorlagen",
      sharesLabel: "\u{1F4E4} Teilungen",
      exportData: "\u{1F4E5} Daten Exportieren",
      invalidKeyFormat: "Ung\xFCltiges API-Schl\xFCsselformat",
      cannotLoadModels: "Modelle k\xF6nnen nicht geladen werden - API-Schl\xFCssel m\xF6glicherweise ung\xFCltig",
      noModelsFound: "Keine kompatiblen Modelle gefunden"
    }
  };
  function updateUILanguage(lang) {
    const t = translations[lang] || translations.English;
    const title = document.querySelector("#settingsPanel h2");
    if (title) title.textContent = t.title;
    const providerLabel = document.querySelector('label[for="providerSelect"]');
    if (providerLabel) providerLabel.textContent = t.providerLabel;
    const apiKeyLabel = document.querySelector('label[for="geminiApiKey"]');
    if (apiKeyLabel) apiKeyLabel.textContent = t.apiKeyLabel;
    const openrouterKeyLabel = document.querySelector('label[for="openrouterApiKey"]');
    if (openrouterKeyLabel) openrouterKeyLabel.textContent = t.openrouterKeyLabel;
    const geminiHelpText = document.getElementById("geminiKeyHelpText");
    if (geminiHelpText) geminiHelpText.textContent = t.apiHelp;
    const openrouterHelpText = document.getElementById("openrouterKeyHelpText");
    if (openrouterHelpText) openrouterHelpText.textContent = t.apiHelp;
    const langLabel = document.querySelector('label[for="languageSelect"]');
    if (langLabel) langLabel.textContent = t.languageLabel;
    const darkModeLabel = document.querySelector('label[for="darkMode"]');
    if (darkModeLabel) darkModeLabel.textContent = t.darkModeLabel;
    const offlineModeLabel = document.querySelector('label[for="offlineMode"]');
    if (offlineModeLabel) offlineModeLabel.textContent = t.offlineModeLabel;
    const saveBtn = document.getElementById("saveKey");
    if (saveBtn) saveBtn.textContent = t.saveButton;
    const settingsTab = document.getElementById("settingsTab");
    if (settingsTab) settingsTab.textContent = t.settingsTab;
    const statsTab = document.getElementById("statsTab");
    if (statsTab) statsTab.textContent = t.statsTab;
    const statsTitle = document.querySelector("#statsPanel h2");
    if (statsTitle) statsTitle.textContent = t.statsTitle;
    const exportBtn = document.getElementById("exportBtn");
    if (exportBtn) exportBtn.textContent = t.exportData;
  }
  document.getElementById("providerSelect")?.addEventListener("change", (e) => {
    const isOpenRouter = e.target.value === "openrouter";
    const geminiGroup = document.getElementById("geminiKeyGroup");
    const geminiModelGroup = document.getElementById("geminiModelGroup");
    const openrouterGroup = document.getElementById("openrouterKeyGroup");
    const openrouterModelGroup = document.getElementById("openrouterModelGroup");
    const geminiHelp = document.getElementById("geminiKeyHelp");
    const openrouterHelp = document.getElementById("openrouterKeyHelp");
    if (geminiGroup) geminiGroup.style.display = isOpenRouter ? "none" : "block";
    if (geminiModelGroup) geminiModelGroup.style.display = isOpenRouter ? "none" : "block";
    if (openrouterGroup) openrouterGroup.style.display = isOpenRouter ? "block" : "none";
    if (openrouterModelGroup) openrouterModelGroup.style.display = isOpenRouter ? "block" : "none";
    if (geminiHelp) geminiHelp.style.display = isOpenRouter ? "none" : "block";
    if (openrouterHelp) openrouterHelp.style.display = isOpenRouter ? "block" : "none";
  });
  document.addEventListener("DOMContentLoaded", async () => {
    const data = await chrome.storage.local.get(["aiProvider", "geminiApiKey", "openrouterApiKey", "selectedLanguage", "darkMode", "offlineMode"]);
    const { providerSelect, geminiApiKey: geminiInput, openrouterApiKey: openrouterInput, languageSelect: langSelect, darkMode: darkModeCheckbox } = getElements();
    if (providerSelect) {
      providerSelect.value = data.aiProvider || "google";
      const isOpenRouter = (data.aiProvider || "google") === "openrouter";
      const geminiGroup = document.getElementById("geminiKeyGroup");
      const geminiModelGroup = document.getElementById("geminiModelGroup");
      const openrouterGroup = document.getElementById("openrouterKeyGroup");
      const openrouterModelGroup = document.getElementById("openrouterModelGroup");
      const geminiHelp = document.getElementById("geminiKeyHelp");
      const openrouterHelp = document.getElementById("openrouterKeyHelp");
      if (geminiGroup) geminiGroup.style.display = isOpenRouter ? "none" : "block";
      if (geminiModelGroup) geminiModelGroup.style.display = isOpenRouter ? "none" : "block";
      if (openrouterGroup) openrouterGroup.style.display = isOpenRouter ? "block" : "none";
      if (openrouterModelGroup) openrouterModelGroup.style.display = isOpenRouter ? "block" : "none";
      if (geminiHelp) geminiHelp.style.display = isOpenRouter ? "none" : "block";
      if (openrouterHelp) openrouterHelp.style.display = isOpenRouter ? "block" : "none";
    }
    if (geminiInput && data.geminiApiKey) {
      geminiInput.value = data.geminiApiKey;
      if (/^AIza[0-9A-Za-z_-]{35}$/.test(data.geminiApiKey)) {
        geminiInput.classList.add("valid");
        if (data.aiProvider !== "openrouter" && !isLoadingModels) {
          isLoadingModels = true;
          console.log("[Chuckle] Auto-validating models for stored key");
          try {
            await validateAndSetupModels(data.geminiApiKey, "google", (msg, type) => {
              const { statusMsg } = getElements();
              if (statusMsg) {
                statusMsg.textContent = type === "error" ? `\u26A0\uFE0F ${msg}` : type === "success" ? `\u2713 ${msg}` : msg;
                statusMsg.className = `status-msg ${type === "error" ? "error" : type === "success" ? "success" : ""}`;
                if (type === "success") {
                  setTimeout(() => {
                    statusMsg.textContent = "";
                    statusMsg.className = "status-msg";
                  }, 2e3);
                }
              }
            }).then((success) => {
              if (success) {
                chrome.storage.local.get(["primaryModel"]).then((data2) => {
                  if (data2.primaryModel) updateModelLabel("geminiModelLabel", data2.primaryModel);
                });
              }
            });
          } finally {
            isLoadingModels = false;
          }
        }
      }
    }
    if (openrouterInput && data.openrouterApiKey) {
      openrouterInput.value = data.openrouterApiKey;
      if (/^sk-or-v1-[a-f0-9]{64}$/.test(data.openrouterApiKey)) {
        openrouterInput.classList.add("valid");
        if (data.aiProvider === "openrouter") {
          await validateAndSetupModels(data.openrouterApiKey, "openrouter", (msg, type) => {
            const { statusMsg } = getElements();
            if (statusMsg) {
              statusMsg.textContent = type === "error" ? `\u26A0\uFE0F ${msg}` : type === "success" ? `\u2713 ${msg}` : msg;
              statusMsg.className = `status-msg ${type === "error" ? "error" : type === "success" ? "success" : ""}`;
              if (type === "success") {
                setTimeout(() => {
                  statusMsg.textContent = "";
                  statusMsg.className = "status-msg";
                }, 2e3);
              }
            }
          }).then((success) => {
            if (success) {
              chrome.storage.local.get(["openrouterPrimaryModel"]).then((data2) => {
                if (data2.openrouterPrimaryModel) updateModelLabel("openrouterModelLabel", data2.openrouterPrimaryModel);
              });
            }
          });
        }
      }
    }
    if (langSelect && data.selectedLanguage) {
      langSelect.value = data.selectedLanguage;
      updateUILanguage(data.selectedLanguage);
    }
    if (darkModeCheckbox) {
      darkModeCheckbox.checked = data.darkMode !== void 0 ? data.darkMode : true;
      if (darkModeCheckbox.checked) document.body.classList.add("dark");
    }
    const offlineModeCheckbox = document.getElementById("offlineMode");
    if (offlineModeCheckbox) {
      offlineModeCheckbox.checked = data.offlineMode || false;
    }
    const { primaryModel, openrouterPrimaryModel } = await chrome.storage.local.get(["primaryModel", "openrouterPrimaryModel"]);
    if (primaryModel) {
      updateModelLabel("geminiModelLabel", primaryModel);
    }
    if (openrouterPrimaryModel && !openrouterPrimaryModel.includes("scout")) {
      updateModelLabel("openrouterModelLabel", openrouterPrimaryModel);
    }
    document.getElementById("settingsTab")?.addEventListener("click", () => switchTab("settings"));
    document.getElementById("statsTab")?.addEventListener("click", () => switchTab("stats"));
    langSelect?.addEventListener("change", (e) => {
      const lang = e.target.value;
      updateUILanguage(lang);
    });
    async function switchTab(tab) {
      ["settings", "stats"].forEach((t) => {
        const panel = document.getElementById(`${t}Panel`);
        const btn = document.getElementById(`${t}Tab`);
        if (panel) panel.style.display = t === tab ? "block" : "none";
        if (btn) {
          btn.style.background = t === tab ? "linear-gradient(135deg, #667eea 0%, #764ba2 100%)" : "#f5f5f5";
          btn.style.color = t === tab ? "white" : "#666";
        }
      });
      if (tab === "stats") await loadStats();
    }
    document.getElementById("exportBtn")?.addEventListener("click", exportData);
    document.getElementById("openrouterModelSelect")?.addEventListener("change", async (e) => {
      const selectedModel = e.target.value;
      if (selectedModel) {
        await chrome.storage.local.set({ openrouterPrimaryModel: selectedModel });
        const modelName = selectedModel.split("/").pop();
        const tooltip = document.getElementById("openrouterModelTooltip");
        if (tooltip) tooltip.textContent = `\u{1F916} ${modelName}`;
      }
    });
  });
  async function loadStats() {
    const { selectedLanguage } = await chrome.storage.local.get(["selectedLanguage"]);
    const lang = selectedLanguage || "English";
    const t = translations[lang] || translations.English;
    const stats = await getAnalytics();
    const content = document.getElementById("statsContent");
    content.innerHTML = `
    <div style="display: grid; gap: 12px;">
      <div style="padding: 12px; background: #f5f5f5; border-radius: 8px;">
        <div style="font-size: 24px; font-weight: 700; color: #667eea;">${stats.totalMemes}</div>
        <div style="font-size: 10px; color: #666; text-transform: uppercase;">${t.totalMemes}</div>
      </div>
      ${stats.topTemplates.length ? `
      <div style="padding: 12px; background: #f5f5f5; border-radius: 8px;">
        <div style="font-size: 11px; font-weight: 600; margin-bottom: 6px;">${t.topTemplates}</div>
        ${stats.topTemplates.map((item) => `<div style="font-size: 10px; color: #666;">${item.name}: ${item.count}</div>`).join("")}
      </div>` : ""}
      <div style="padding: 12px; background: #f5f5f5; border-radius: 8px;">
        <div style="font-size: 11px; font-weight: 600; margin-bottom: 6px;">${t.sharesLabel}</div>
        <div style="font-size: 10px; color: #666;">\u{1D54F} Twitter: ${stats.shareStats.twitter}</div>
        <div style="font-size: 10px; color: #666;">\u{1F4BC} LinkedIn: ${stats.shareStats.linkedin}</div>
        <div style="font-size: 10px; color: #666;">\u{1F4E7} Email: ${stats.shareStats.email}</div>
      </div>
    </div>
  `;
  }
  document.getElementById("darkMode")?.addEventListener("change", (e) => {
    const checked = e.target.checked;
    document.body.classList.toggle("dark", checked);
    chrome.storage.local.set({ darkMode: checked });
  });
  document.getElementById("offlineMode")?.addEventListener("change", (e) => {
    const checked = e.target.checked;
    chrome.storage.local.set({ offlineMode: checked });
  });
  var geminiKeyTimeout;
  var isLoadingModels = false;
  document.getElementById("geminiApiKey")?.addEventListener("input", (e) => {
    const key = e.target.value.trim();
    const input = e.target;
    clearTimeout(geminiKeyTimeout);
    if (key.length >= 39 && /^AIza[0-9A-Za-z_-]{35}$/.test(key)) {
      input.classList.add("valid");
      geminiKeyTimeout = setTimeout(async () => {
        if (!isLoadingModels) {
          isLoadingModels = true;
          console.log("[Chuckle] Auto-validating models for key input");
          try {
            await validateAndSetupModels(key, "google", (msg, type) => {
              const { statusMsg } = getElements();
              if (statusMsg) {
                statusMsg.textContent = type === "error" ? `\u26A0\uFE0F ${msg}` : type === "success" ? `\u2713 ${msg}` : msg;
                statusMsg.className = `status-msg ${type === "error" ? "error" : type === "success" ? "success" : ""}`;
                if (type === "success") {
                  setTimeout(() => {
                    statusMsg.textContent = "";
                    statusMsg.className = "status-msg";
                  }, 2e3);
                }
              }
            }).then((success) => {
              if (success) {
                chrome.storage.local.get(["primaryModel"]).then((data) => {
                  if (data.primaryModel) updateModelLabel("geminiModelLabel", data.primaryModel);
                });
              }
            });
          } finally {
            isLoadingModels = false;
          }
        }
      }, 1e3);
    } else {
      input.classList.remove("valid");
    }
  });
  var openrouterKeyTimeout;
  document.getElementById("openrouterApiKey")?.addEventListener("input", (e) => {
    const key = e.target.value.trim();
    const input = e.target;
    clearTimeout(openrouterKeyTimeout);
    if (key.length >= 20 && /^sk-or-v1-[a-f0-9]{64}$/.test(key)) {
      input.classList.add("valid");
      openrouterKeyTimeout = setTimeout(async () => {
        await validateAndSetupModels(key, "openrouter", (msg, type) => {
          const { statusMsg } = getElements();
          if (statusMsg) {
            statusMsg.textContent = type === "error" ? `\u26A0\uFE0F ${msg}` : type === "success" ? `\u2713 ${msg}` : msg;
            statusMsg.className = `status-msg ${type === "error" ? "error" : type === "success" ? "success" : ""}`;
            if (type === "success") {
              setTimeout(() => {
                statusMsg.textContent = "";
                statusMsg.className = "status-msg";
              }, 2e3);
            }
          }
        }).then((success) => {
          if (success) {
            chrome.storage.local.get(["openrouterPrimaryModel"]).then((data) => {
              if (data.openrouterPrimaryModel) updateModelLabel("openrouterModelLabel", data.openrouterPrimaryModel);
            });
          }
        });
      }, 1e3);
    } else {
      input.classList.remove("valid");
    }
  });
  document.getElementById("saveKey")?.addEventListener("click", async () => {
    const { providerSelect, geminiApiKey: geminiInput, openrouterApiKey: openrouterInput, languageSelect: langSelect, statusMsg } = getElements();
    const saveBtn = document.getElementById("saveKey");
    if (!statusMsg) return;
    const provider = providerSelect.value;
    const geminiKey = geminiInput.value.trim();
    const openrouterKey = openrouterInput.value.trim();
    const lang = langSelect.value;
    const t = translations[lang] || translations.English;
    if (provider === "google") {
      if (!geminiKey || !/^AIza[0-9A-Za-z_-]{35}$/.test(geminiKey)) {
        statusMsg.textContent = `\u26A0\uFE0F ${t.invalidKeyFormat}`;
        statusMsg.className = "status-msg error";
        geminiInput.style.borderColor = "#c5221f";
        setTimeout(() => {
          statusMsg.textContent = "";
          statusMsg.className = "status-msg";
          geminiInput.style.borderColor = "";
        }, 4e3);
        return;
      }
    } else {
      if (!openrouterKey || !/^sk-or-v1-[a-f0-9]{64}$/.test(openrouterKey)) {
        statusMsg.textContent = `\u26A0\uFE0F ${t.invalidKeyFormat}`;
        statusMsg.className = "status-msg error";
        openrouterInput.style.borderColor = "#c5221f";
        setTimeout(() => {
          statusMsg.textContent = "";
          statusMsg.className = "status-msg";
          openrouterInput.style.borderColor = "";
        }, 4e3);
        return;
      }
    }
    try {
      if (saveBtn) saveBtn.disabled = true;
      statusMsg.textContent = "Saving settings...";
      statusMsg.className = "status-msg";
      let primary, fallbacks;
      if (provider === "google") {
        const { primaryModel, fallbackModels } = await chrome.storage.local.get(["primaryModel", "fallbackModels"]);
        primary = primaryModel;
        fallbacks = fallbackModels || [];
      } else {
        const { openrouterPrimaryModel, openrouterFallbackModels } = await chrome.storage.local.get(["openrouterPrimaryModel", "openrouterFallbackModels"]);
        primary = openrouterPrimaryModel;
        fallbacks = openrouterFallbackModels || [];
      }
      const offlineModeCheckbox = document.getElementById("offlineMode");
      const offlineMode = offlineModeCheckbox?.checked || false;
      const storageData = {
        aiProvider: provider,
        geminiApiKey: geminiKey,
        openrouterApiKey: openrouterKey,
        selectedLanguage: lang,
        offlineMode
      };
      if (provider === "google" && primary) {
        storageData.primaryModel = primary;
        storageData.fallbackModels = fallbacks;
      } else if (provider === "openrouter" && primary) {
        storageData.openrouterPrimaryModel = primary;
        storageData.openrouterFallbackModels = fallbacks;
      }
      await chrome.storage.local.set(storageData);
      if (provider === "google" && primary) {
        updateModelLabel("geminiModelLabel", primary);
      } else if (provider === "openrouter" && primary) {
        updateModelLabel("openrouterModelLabel", primary);
      }
      updateUILanguage(lang);
      statusMsg.textContent = `\u2713 ${t.saved}`;
      statusMsg.className = "status-msg success";
      if (provider === "google") {
        geminiInput.classList.add("valid");
        geminiInput.style.borderColor = "";
      } else {
        openrouterInput.classList.add("valid");
        openrouterInput.style.borderColor = "";
      }
      setTimeout(() => {
        statusMsg.textContent = "";
        statusMsg.className = "status-msg";
      }, 2e3);
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : "Failed to save settings";
      statusMsg.textContent = `\u26A0\uFE0F ${errorMsg}`;
      statusMsg.className = "status-msg error";
      if (provider === "google") {
        geminiInput.style.borderColor = "#c5221f";
      } else {
        openrouterInput.style.borderColor = "#c5221f";
      }
      setTimeout(() => {
        statusMsg.textContent = "";
        statusMsg.className = "status-msg";
        geminiInput.style.borderColor = "";
        openrouterInput.style.borderColor = "";
      }, 5e3);
    } finally {
      if (saveBtn) saveBtn.disabled = false;
    }
  });
  var darkStyle = document.createElement("style");
  darkStyle.textContent = `
  body.dark .tab-btn { background: #2a2a3e !important; color: #e0e0e0 !important; }
  body.dark .tab-btn.active { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important; color: white !important; }
  body.dark #statsContent > div > div { background: #2a2a3e !important; color: #e0e0e0 !important; }
`;
  document.head.appendChild(darkStyle);
})();
