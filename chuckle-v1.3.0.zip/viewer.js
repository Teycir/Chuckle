"use strict";
(() => {
  // src/constants.ts
  var MEME_TEMPLATES = [
    {
      id: "drake",
      name: "Drake",
      topics: ["choice", "preference", "comparison", "rejection", "approval"]
    },
    {
      id: "db",
      name: "Distracted BF",
      topics: ["temptation", "distraction", "betrayal", "choice", "infidelity"]
    },
    {
      id: "ds",
      name: "Daily Struggle",
      topics: ["impossible choice", "dilemma", "absurd", "stress", "panic"]
    },
    {
      id: "cmm",
      name: "Change My Mind",
      topics: ["opinion", "debate", "controversial", "statement", "challenge"]
    },
    {
      id: "pigeon",
      name: "Pigeon",
      topics: ["confusion", "misunderstanding", "wrong", "mistake", "identification"]
    },
    {
      id: "woman-cat",
      name: "Woman Cat",
      topics: ["argument", "accusation", "defense", "dismissal", "conflict"]
    },
    { id: "fine", name: "This Is Fine", topics: ["denial", "disaster", "chaos", "cope", "fire"] },
    { id: "stonks", name: "Stonks", topics: ["success", "profit", "unexpected", "win", "growth"] },
    {
      id: "success",
      name: "Success Kid",
      topics: ["victory", "achievement", "win", "triumph", "celebration"]
    },
    {
      id: "blb",
      name: "Bad Luck Brian",
      topics: ["failure", "misfortune", "unlucky", "disaster", "backfire"]
    },
    {
      id: "fry",
      name: "Futurama Fry",
      topics: ["suspicion", "doubt", "uncertain", "paranoid", "question"]
    },
    {
      id: "fwp",
      name: "First World",
      topics: ["privilege", "complaint", "minor", "luxury", "trivial"]
    },
    { id: "doge", name: "Doge", topics: ["excitement", "enthusiasm", "wow", "much", "very"] },
    {
      id: "iw",
      name: "Insanity Wolf",
      topics: ["extreme", "crazy", "overreaction", "insane", "wild"]
    },
    {
      id: "philosoraptor",
      name: "Philosoraptor",
      topics: ["philosophy", "deep", "thinking", "paradox", "question"]
    },
    {
      id: "grumpycat",
      name: "Grumpy Cat",
      topics: ["grumpy", "rejection", "no", "refusal", "negative"]
    }
  ];
  var PROMPT_TEMPLATE = (text, topic) => `Analyze this text and suggest ONE meme template from this list: db (distracted boyfriend), drake, ds (two buttons - sweating over impossible choices), cmm (change my mind), pigeon, woman-cat, fine (this is fine), stonks, success, blb (bad luck brian), fry (futurama fry), fwp (first world problems), doge, iw (insanity wolf), philosoraptor, grumpycat. Text: "${text}".${topic ? ` Topic: ${topic}.` : ""} Return ONLY the template ID (e.g., "db", "drake"). No explanation.`;

  // src/config.ts
  var CONFIG = {
    IMGFLIP_API_URL: "https://api.imgflip.com/caption_image",
    MEMEGEN_API_URL: "https://api.memegen.link/images",
    FALLBACK_IMAGE_URL: "https://api.memegen.link/images/drake/meme_generation_failed/please_try_again.png",
    DEBOUNCE_DELAY: 150,
    MAX_TAG_LENGTH: 100,
    MAX_HISTORY_ITEMS: 1e3,
    MAX_UNDO_STACK: 20,
    CACHE_TTL_MS: 36e5
  };

  // lib/lru-cache.ts
  var LRUCache = class {
    /**
     * Creates a new LRU Cache
     * @param maxSize - Maximum number of entries (default: 100)
     * @param ttlMs - Time to live in milliseconds (default: 3600000 = 1 hour)
     */
    constructor(maxSize = 100, ttlMs = 36e5) {
      this.cache = /* @__PURE__ */ new Map();
      this.maxSize = maxSize;
      this.ttl = ttlMs;
    }
    /**
     * Gets a value from cache
     * @param key - Cache key
     * @returns Cached value or null if not found/expired
     */
    get(key) {
      const entry = this.cache.get(key);
      if (!entry) return null;
      if (Date.now() - entry.timestamp > this.ttl) {
        this.cache.delete(key);
        return null;
      }
      this.cache.delete(key);
      this.cache.set(key, entry);
      return entry.value;
    }
    /**
     * Sets a value in cache
     * @param key - Cache key
     * @param value - Value to cache
     */
    set(key, value) {
      if (this.cache.size >= this.maxSize) {
        const firstKey = this.cache.keys().next().value;
        if (firstKey) this.cache.delete(firstKey);
      }
      this.cache.set(key, { value, timestamp: Date.now() });
    }
    /**
     * Clears all entries from cache
     */
    clear() {
      this.cache.clear();
    }
  };

  // src/cache.ts
  var apiCache = new LRUCache();
  var formattedCache = new LRUCache(100, 36e5);

  // lib/logger.ts
  var Logger = class {
    constructor(prefix, debug = false) {
      this.prefix = prefix;
      this.debug = debug;
    }
    /**
     * Log informational message (only in debug mode)
     */
    info(message, ...args) {
      if (this.debug) console.log(`[${this.prefix}] ${message}`, ...args);
    }
    /**
     * Log error message (always shown)
     */
    error(message, error) {
      console.error(`[${this.prefix} Error] ${message}`, error);
    }
    /**
     * Log warning message (only in debug mode)
     */
    warn(message, ...args) {
      if (this.debug) console.warn(`[${this.prefix} Warning] ${message}`, ...args);
    }
  };

  // src/logger.ts
  var DEBUG = false;
  var logger = new Logger("Chuckle", DEBUG);

  // src/errorMessages.ts
  var ERROR_MESSAGES = {
    English: {
      tooManyRequests: "API exhausted. Please wait a moment and try again.",
      generationFailed: "Meme generation failed. Please try again.",
      noApiKey: "API key not configured. Please add your API key in settings.",
      invalidApiKey: "Invalid API key format.",
      networkError: "Network error. Check your internet connection.",
      templateUnavailable: "Template unavailable. Please try another template."
    },
    Spanish: {
      tooManyRequests: "API agotada. Por favor, espera un momento e int\xE9ntalo de nuevo.",
      generationFailed: "Generaci\xF3n de meme fallida. Por favor, int\xE9ntalo de nuevo.",
      noApiKey: "Clave API no configurada. Por favor, agrega tu clave API en la configuraci\xF3n.",
      invalidApiKey: "Formato de clave API inv\xE1lido.",
      networkError: "Error de red. Verifica tu conexi\xF3n a internet.",
      templateUnavailable: "Plantilla no disponible. Por favor, prueba otra plantilla."
    },
    French: {
      tooManyRequests: "API \xE9puis\xE9e. Veuillez attendre un moment et r\xE9essayer.",
      generationFailed: "\xC9chec de la g\xE9n\xE9ration du meme. Veuillez r\xE9essayer.",
      noApiKey: "Cl\xE9 API non configur\xE9e. Veuillez ajouter votre cl\xE9 API dans les param\xE8tres.",
      invalidApiKey: "Format de cl\xE9 API invalide.",
      networkError: "Erreur r\xE9seau. V\xE9rifiez votre connexion internet.",
      templateUnavailable: "Mod\xE8le non disponible. Veuillez essayer un autre mod\xE8le."
    },
    German: {
      tooManyRequests: "API ersch\xF6pft. Bitte warten Sie einen Moment und versuchen Sie es erneut.",
      generationFailed: "Meme-Generierung fehlgeschlagen. Bitte versuchen Sie es erneut.",
      noApiKey: "API-Schl\xFCssel nicht konfiguriert. Bitte f\xFCgen Sie Ihren API-Schl\xFCssel in den Einstellungen hinzu.",
      invalidApiKey: "Ung\xFCltiges API-Schl\xFCsselformat.",
      networkError: "Netzwerkfehler. \xDCberpr\xFCfen Sie Ihre Internetverbindung.",
      templateUnavailable: "Vorlage nicht verf\xFCgbar. Bitte versuchen Sie eine andere Vorlage."
    }
  };
  async function getErrorMessage(key) {
    const { selectedLanguage } = await chrome.storage.local.get(["selectedLanguage"]);
    const lang = selectedLanguage || "English";
    return ERROR_MESSAGES[lang]?.[key] || ERROR_MESSAGES.English[key];
  }

  // src/watermark.ts
  async function addWatermark(imageUrl) {
    return new Promise((resolve, reject) => {
      const img2 = new Image();
      img2.crossOrigin = "anonymous";
      img2.onload = () => {
        const canvas = document.createElement("canvas");
        const ctx = canvas.getContext("2d");
        if (!ctx) return reject(new Error("Canvas not supported"));
        canvas.width = img2.width;
        canvas.height = img2.height;
        ctx.drawImage(img2, 0, 0);
        const fontSize = Math.max(12, img2.height * 0.03);
        ctx.font = `${fontSize}px Arial`;
        ctx.fillStyle = "rgba(255, 255, 255, 0.8)";
        ctx.strokeStyle = "rgba(0, 0, 0, 0.5)";
        ctx.lineWidth = 2;
        const text = "teycirbensoltane.tn";
        const padding = 10;
        const x = img2.width - ctx.measureText(text).width - padding;
        const y = img2.height - padding;
        ctx.strokeText(text, x, y);
        ctx.fillText(text, x, y);
        resolve(canvas.toDataURL("image/png"));
      };
      img2.onerror = () => reject(new Error("Failed to load image"));
      img2.src = imageUrl;
    });
  }

  // lib/text-utils.ts
  function decodeHtmlEntities(text) {
    const entities = {
      "&quot;": '"',
      "&#34;": '"',
      "&apos;": "'",
      "&#39;": "'",
      "&amp;": "&",
      "&#38;": "&",
      "&lt;": "<",
      "&#60;": "<",
      "&gt;": ">",
      "&#62;": ">",
      "&nbsp;": " ",
      "&#160;": " "
    };
    return text.replace(/&[#a-z0-9]+;/gi, (match) => entities[match.toLowerCase()] || "");
  }
  function removeEmojis(text) {
    return text.replace(/[\u{1F300}-\u{1F9FF}]/gu, "").replace(/[\u{2600}-\u{26FF}]/gu, "").replace(/[\u{2700}-\u{27BF}]/gu, "");
  }
  function sanitizeText(text) {
    return text.replace(/[*#@]/g, "").replace(/\s+/g, " ").trim();
  }
  function cleanText(text) {
    return sanitizeText(removeEmojis(text));
  }

  // src/templateFormatter.ts
  var TEMPLATE_PROMPTS = {
    drake: 'Drake (rejecting/approving): TOP=rejected option (what Drake pushes away), BOTTOM=OPPOSITE approved option (what Drake wants). CRITICAL: TOP and BOTTOM must be CONTRADICTORY. Example: TOP="Therapy and self-care" BOTTOM="Ignoring problems until they disappear". Photo: Drake rapper in red jacket, top panel shows him turning away disgusted, bottom panel shows him pointing and smiling approvingly.',
    db: 'Distracted Boyfriend: TOP=tempting new thing only, BOTTOM=current thing being ignored. About temptation only. Example: TOP="ChatGPT writing my code" BOTTOM="Actually learning to code". Photo: Man walking with girlfriend, turns to check out another woman passing by, girlfriend looks angry.',
    ds: 'Daily struggle (sweating): TOP=first equally horrible option, BOTTOM=second equally horrible option. CRITICAL: Both choices must be EQUALLY BAD/TERRIBLE - no good option exists. Example: TOP="Admit I was wrong" BOTTOM="Get fired". Photo: Man in suit sweating nervously, hand hovering over two red buttons, unable to choose.',
    cmm: 'Change My Mind: One single controversial statement (no TOP/BOTTOM split). Example: "Pineapple belongs on pizza". Photo: Man sitting at table with sign that says "Change My Mind", ready to debate.',
    pigeon: 'Pigeon (Is this...?): TOP=tiny/pathetic thing, BOTTOM="Is this [absurdly grand label]?". About ridiculous misidentification. Example: TOP="Got 3 likes on my post" BOTTOM="Am I megastar or superstar?". Photo: Pigeon looking at butterfly, confused about what it is.',
    "woman-cat": `Woman Yelling at Cat: TOP=angry woman yelling accusation, BOTTOM=cat SADISTIC response that ENJOYS the pain/problem. CRITICAL: Cat must be CRUEL, SADISTIC, take PLEASURE in the accusation, and respond with MALICIOUS satisfaction. Cat LOVES causing suffering. Example 1: TOP="You are ruining your life!" BOTTOM="And I'll do it again". Example 2: TOP="Ils nous divisent!" BOTTOM="Bien fait". Photo: Woman yelling (left), cat at table unbothered (right).`,
    fine: 'This is Fine (dog in fire): TOP=very catastrophic situation and desparate, BOTTOM=denial during disaster, accepting fate, extemely passive and accepting catastrophy, total submission. Example: TOP="Bank account at -$47, rent due tomorrow" BOTTOM="This is fine". Photo: Dog sitting at table drinking coffee while room is on fire around him, smiling calmly.',
    stonks: 'Stonks: TOP=huge failure/mistake, BOTTOM=unexpected huge success DESPITE the failure. CRITICAL: BOTTOM must be POSITIVE/WIN/SUCCESS, not another failure. Example: TOP="Accidentally replied all with meme" BOTTOM="CEO loved it, got promoted". Photo: Orange meme man in suit with rising stock chart arrow behind him, looking confident.',
    success: `Success Kid (fist pump): TOP=challenge/obstacle, BOTTOM=petty victory or savage comeback, winner attitude and optimism. Example: TOP="Ex said I'd never find better" BOTTOM="Now married to a top model". Photo: Baby on beach with determined expression, fist clenched in victory pose.`,
    blb: 'Bad Luck Brian: TOP=big action taken, BOTTOM=catastrophic outcome. Example: TOP="Finally gets a date" BOTTOM="She brings her boyfriend". Photo: Awkward teen with braces, red plaid vest, terrible school photo smile.',
    fry: 'Futurama Fry (squinting): TOP="Not sure if [first option]", BOTTOM="Or [second option]". Very paranoid, at limit of insanity. Example: TOP="Not sure if flirting" BOTTOM="Or is a Russian spy try to seduce me". Photo: Fry from Futurama squinting suspiciously, orange hair, red jacket.',
    fwp: 'First World Problems: TOP=ridiculously privileged complaint on a tiny problem, BOTTOM=why it ruins everything, extreme over reaction to a tiny problem. Spoiled brat question and answer. Example: TOP="My AirPods died" BOTTOM=" I am going to open my veins". Photo: Woman crying while holding phone, looking devastated over trivial problem.',
    doge: 'Doge: Broken English, enthusiastic. TOP="much/wow [thing]", BOTTOM="such/very [thing] wow". Funny breaking of the language. Example: TOP="much procrastinate" BOTTOM="very deadline panic wow". Photo: Shiba Inu dog with raised eyebrows, looking sideways with comic sans text.',
    iw: 'Insanity Wolf: TOP=normal situation, BOTTOM=EXTREME overreaction. Example: TOP="Someone says good morning" BOTTOM="SCREAM BACK AGGRESSIVELY". Be creative an hilarious, use exageration to the absurd. Photo: Wolf with crazy eyes, teeth bared, insane aggressive expression.',
    philosoraptor: `Philosoraptor: TOP=first part of mind-bending question, BOTTOM=second part that makes you think. Be creative an hilarious. Example: TOP="If I'm always late" BOTTOM="Am I consistently on time for being late?". Photo: Velociraptor in thinking pose, claw on chin, contemplating deeply.`,
    grumpycat: 'Grumpy Cat: TOP=suggestion/request, BOTTOM=witty grumpy rejection with extreme snobism and sarcasm. Be creative and hilarious to a point were we laugh hard, not just "No". Example: TOP="Be more positive" BOTTOM="I choose violence". Photo: Grumpy white cat with permanently angry/frowning face, looking extremely displeased.'
  };
  async function formatTextForTemplate(text, template, forceRegenerate = false) {
    const { offlineMode } = await chrome.storage.local.get(["offlineMode"]);
    if (offlineMode) {
      console.log("[Chuckle] Offline mode: splitting text in half");
      const words = text.trim().split(/\s+/);
      const mid = Math.ceil(words.length / 2);
      const part1 = words.slice(0, mid).join(" ");
      const part2 = words.slice(mid).join(" ");
      return `${part1} / ${part2}`;
    }
    const cacheKey = `fmt:${template}:${text.slice(0, 50)}`;
    if (!forceRegenerate) {
      const cached = formattedCache.get(cacheKey);
      if (cached) {
        console.log("[Chuckle] Using cached formatted text");
        return cached;
      }
    }
    const templatePrompt = TEMPLATE_PROMPTS[template] || 'Format as two parts: "part 1 / part 2" (max 35 chars each)';
    console.log(`[Chuckle] Formatting text for ${template}`);
    const { openrouterApiKey, openrouterPrimaryModel, selectedLanguage } = await chrome.storage.local.get(["openrouterApiKey", "openrouterPrimaryModel", "selectedLanguage"]);
    const language = selectedLanguage || "English";
    const model = openrouterPrimaryModel || "meta-llama/llama-3.2-3b-instruct:free";
    if (!openrouterApiKey) throw new Error("No API key");
    const prompt = `Format: "${text}"

Template: ${templatePrompt}

RULES:
1. Return ONLY: "text1 / text2"
2. Each part MAX 70 chars
3. Language: ${language}
4. Be concise and viral
5. CRITICAL: Be concise and creative - rephrase to fit within 70 chars
6. NEVER truncate words ("du moin" is WRONG, must be "du moins" or rephrase entirely)
7. Plan your text from the start to fit 70 chars - write complete sentences that naturally fit
8. PREFER 3-4 words max in part 1 and part 2 IF POSSIBLE - shorter is punchier and more viral

CRITICAL - Choose ONE definitive answer:
- NO alternatives ("OR", "Alternatively", "could be")
- NO thinking process or commentary
- NO multiple options
- Just return the FINAL result

FORBIDDEN - DO NOT INCLUDE:
- Your thoughts
- Explanations
- Commentary
- "Let me", "Here is", "according to", "I will"
- ANY text outside the 2 parts

Response (ONLY the 2 parts):`;
    try {
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${openrouterApiKey}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model,
          messages: [{ role: "user", content: prompt }],
          temperature: 0.7,
          top_p: 0.85,
          max_tokens: 80
        })
      });
      if (!response.ok) {
        if (response.status === 429) {
          const errorMsg = await getErrorMessage("tooManyRequests");
          throw new Error(errorMsg);
        }
        if (response.status === 403 || response.status === 401) {
          throw new Error(`API authentication failed (${response.status})`);
        }
        throw new Error(`API error: ${response.status}`);
      }
      const data = await response.json();
      console.log("[Chuckle] Format API full response:", JSON.stringify(data));
      let formatted = data.choices?.[0]?.message?.content?.trim();
      console.log("[Chuckle] Raw AI response:", formatted);
      if (!formatted) {
        throw new Error("AI returned no visible text output");
      }
      if (formatted) {
        formatted = formatted.replace(/^["']|["']$/g, "").trim();
        formatted = decodeHtmlEntities(formatted);
        formatted = cleanText(formatted);
        const explanationMarkers = [" is not valid", " due to", "A valid", "rephrased version", "Let me", "according to", "Here is", "I will", "The formatted"];
        for (const marker of explanationMarkers) {
          const idx = formatted.toLowerCase().indexOf(marker.toLowerCase());
          if (idx > 0) {
            formatted = formatted.substring(0, idx).trim();
          }
        }
        formatted = formatted.replace(/["']+$/g, "").trim();
        const lines = formatted.split("\n").filter((l) => l.trim().length > 0);
        const firstLine = lines[0] || formatted;
        const separators = [" / ", "/", " /"];
        for (const sep of separators) {
          if (firstLine.includes(sep)) {
            const parts = firstLine.split(sep).map((p) => p.trim());
            if (parts.length >= 2 && parts[0] && parts[1]) {
              const truncatePart = (part, maxLen) => {
                if (part.length <= maxLen) return part;
                const words = part.split(/\s+/);
                let result = "";
                for (const word of words) {
                  if ((result + " " + word).trim().length <= maxLen) {
                    result = (result + " " + word).trim();
                  } else break;
                }
                return result;
              };
              const part1 = truncatePart(parts[0], 80);
              const part2 = truncatePart(parts[1], 80);
              const cleanedLine = `${part1} / ${part2}`;
              console.log("[Chuckle] Text formatted for template:", cleanedLine, `(${part1.length}/${part2.length} chars)`);
              formattedCache.set(cacheKey, cleanedLine);
              return cleanedLine;
            }
          }
        }
      }
      throw new Error("AI failed to format with separator");
    } catch (error) {
      console.error("[Chuckle] Template formatting error:", error);
      if (error instanceof Error && (error.message.includes("429") || error.message.includes("API exhausted") || error.message.includes("API agotada") || error.message.includes("API \xE9puis\xE9e") || error.message.includes("API ersch\xF6pft") || error.message.includes("Too many requests") || error.message.includes("Too Many Requests"))) {
        throw error;
      }
      throw new Error(`Failed to format text for ${template}: ${error}`);
    }
  }

  // src/memeService.ts
  async function fetchWithTimeout(url, options, timeoutMs = 1e4) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
      return await fetch(url, { ...options, signal: controller.signal });
    } finally {
      clearTimeout(timeout);
    }
  }
  async function extractTopic(text, apiKey, model) {
    const prompt = `Extract the main topic/theme from this text in 1-3 words: "${text}". Return ONLY the topic words (e.g., "choice", "failure", "confusion"). No explanation.`;
    try {
      const response = await fetchWithTimeout(
        "https://openrouter.ai/api/v1/chat/completions",
        {
          method: "POST",
          headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
          body: JSON.stringify({
            model: model || "meta-llama/llama-3.2-3b-instruct:free",
            messages: [{ role: "user", content: prompt }],
            temperature: 0.3,
            top_p: 0.8,
            max_tokens: 10
          })
        },
        5e3
      );
      if (!response.ok) return "";
      const data = await response.json();
      console.log("[Chuckle] Topic extraction raw response:", JSON.stringify(data));
      const topic = data.choices?.[0]?.message?.content?.trim().toLowerCase();
      console.log("[Chuckle] Extracted topic:", topic);
      return topic || "";
    } catch (error) {
      console.log("[Chuckle] Topic extraction failed, continuing without topic");
      return "";
    }
  }
  async function analyzeMemeContext(text, variant = 0) {
    const { offlineMode } = await chrome.storage.local.get(["offlineMode"]);
    if (offlineMode) {
      console.log("[Chuckle] Offline mode: using default template");
      return "drake";
    }
    const isRegenerate = variant > 0;
    const cacheKey = `api:${text}${isRegenerate ? `:v${variant}` : ""}`;
    if (!isRegenerate) {
      const cached = apiCache.get(cacheKey);
      if (cached) {
        console.log("[Chuckle] Using cached template:", cached);
        return cached;
      }
    }
    const { openrouterApiKey, openrouterPrimaryModel } = await chrome.storage.local.get(["openrouterApiKey", "openrouterPrimaryModel"]);
    const model = openrouterPrimaryModel || "meta-llama/llama-3.2-3b-instruct:free";
    console.log("[Chuckle] Calling OpenRouter API for text:", text.slice(0, 50), isRegenerate ? "(regenerate)" : "", `| Model: ${model}`);
    if (!openrouterApiKey) throw new Error(await getErrorMessage("noApiKey"));
    const topic = !isRegenerate ? await extractTopic(text, openrouterApiKey, model) : "";
    try {
      const response = await fetchWithTimeout(
        "https://openrouter.ai/api/v1/chat/completions",
        {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${openrouterApiKey}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            model,
            messages: [{
              role: "user",
              content: isRegenerate ? `${PROMPT_TEMPLATE(text)}

IMPORTANT: Provide a DIFFERENT template than you might have suggested before for this text. Choose an alternative that fits the context.` : PROMPT_TEMPLATE(text, topic)
            }],
            temperature: isRegenerate ? 1.3 : 0.7,
            top_p: isRegenerate ? 0.98 : 0.9
          })
        },
        1e4
      );
      if (!response.ok) {
        console.error("[Chuckle] OpenRouter API error:", response.status);
        if (response.status === 429) {
          throw new Error(await getErrorMessage("tooManyRequests"));
        }
        if (response.status === 403 || response.status === 401) {
          throw new Error(await getErrorMessage("invalidApiKey"));
        }
        throw new Error(`API error: ${response.status}`);
      }
      const data = await response.json();
      console.log("[Chuckle] OpenRouter API response received");
      if (data.error) throw new Error(data.error.message);
      if (!data.choices?.[0]?.message?.content) {
        throw new Error(`Invalid API response for text: "${text.slice(0, 50)}..."`);
      }
      const result = data.choices[0].message.content.trim().replace(/\s+/g, " ");
      console.log("[Chuckle] Template from API:", result);
      if (!isRegenerate) {
        apiCache.set(cacheKey, result);
      }
      return result;
    } catch (error) {
      const lastError = error instanceof Error ? error : new Error(String(error));
      console.error("[Chuckle] API call failed:", lastError.message);
      throw lastError;
    }
  }
  function normalizeText(text) {
    const cleaned = text.replace(/[<>"{}|\\^`]/g, "").replace(/\s+/g, "_");
    return encodeURIComponent(cleaned);
  }
  async function generateMemeImage(template, text, skipFormatting = false, forceRegenerate = false) {
    try {
      const formattedTemplate = template.trim().toLowerCase().replace(/\s+/g, "_");
      const formattedText = skipFormatting && text.includes(" / ") ? text : await formatTextForTemplate(text, formattedTemplate, forceRegenerate);
      const cleanText2 = formattedText.replace(/['']/g, "'").replace(/…/g, "...");
      const parts = cleanText2.split(" / ").map((p) => p.trim()).filter((p) => p.length > 0);
      let topText, bottomText;
      console.log("[Chuckle] Split parts:", parts);
      console.log("[Chuckle] Parts count:", parts.length);
      if (formattedTemplate === "cmm") {
        topText = "~";
        bottomText = normalizeText(parts.join("  "));
      } else if (parts.length >= 2) {
        const bottomParts = parts.slice(1);
        const bottomJoined = bottomParts.join(" ");
        topText = normalizeText(parts[0]);
        bottomText = normalizeText(bottomJoined);
        console.log("[Chuckle] Bottom parts:", bottomParts);
        console.log("[Chuckle] Bottom joined BEFORE normalize:", bottomJoined);
        console.log("[Chuckle] Bottom text AFTER normalize:", bottomText);
      } else if (parts.length === 1 && parts[0]) {
        const words = parts[0].split(/\s+/);
        const mid = Math.ceil(words.length / 2);
        topText = normalizeText(words.slice(0, mid).join(" "));
        bottomText = normalizeText(words.slice(mid).join(" ") || "yes");
      } else {
        topText = normalizeText(cleanText2);
        bottomText = "yes";
      }
      console.log("[Chuckle] Formatted template:", formattedTemplate);
      console.log("[Chuckle] FINAL Top text:", topText);
      console.log("[Chuckle] FINAL Bottom text:", bottomText);
      let url;
      if (formattedTemplate === "cmm") {
        url = `${CONFIG.MEMEGEN_API_URL}/${formattedTemplate}/${bottomText}.png`;
      } else if (formattedTemplate === "grumpycat") {
        url = `${CONFIG.MEMEGEN_API_URL}/${formattedTemplate}/${topText}/${bottomText}.png`;
      } else {
        url = `${CONFIG.MEMEGEN_API_URL}/${formattedTemplate}/${topText}/${bottomText}.png`;
      }
      console.log("[Chuckle] FULL meme URL:", url);
      console.log("[Chuckle] Formatted text for display:", cleanText2);
      const response = await fetch(url, { method: "HEAD" });
      if (!response.ok) {
        if (response.status === 429) {
          throw new Error(await getErrorMessage("tooManyRequests"));
        }
        throw new Error("Template unavailable");
      }
      const watermarkedUrl = await addWatermark(url);
      return { watermarkedUrl, originalUrl: url, formattedText: cleanText2 };
    } catch (error) {
      logger.error("Meme image generation failed", error);
      if (error instanceof Error && (error.message.includes("429") || error.message.includes("API exhausted") || error.message.includes("API agotada") || error.message.includes("API \xE9puis\xE9e") || error.message.includes("API ersch\xF6pft") || error.message.includes("Too many requests") || error.message.includes("Too Many Requests") || error.message.includes("authentication failed") || error.message.includes("403") || error.message.includes("401"))) {
        throw error;
      }
      return { watermarkedUrl: CONFIG.FALLBACK_IMAGE_URL, originalUrl: CONFIG.FALLBACK_IMAGE_URL, formattedText: text };
    }
  }

  // src/viewer.ts
  var params = new URLSearchParams(window.location.search);
  var dataStr = params.get("data");
  var memeData = dataStr ? JSON.parse(decodeURIComponent(dataStr)) : null;
  var currentTemplate = memeData?.template;
  var isManualEdit = false;
  var img = document.getElementById("memeImage");
  var textEditor = document.getElementById("textEditor");
  var templatesDiv = document.getElementById("templates");
  var loading = document.getElementById("loading");
  if (memeData) {
    img.src = memeData.imageUrl;
    textEditor.textContent = memeData.text;
    chrome.storage.local.get(["darkMode", "offlineMode"], (data) => {
      if (data.darkMode) document.body.classList.add("dark");
      isOffline = data.offlineMode || false;
      if (offlineIcon && offlineText) {
        offlineIcon.textContent = isOffline ? "\u{1F4F4}" : "\u{1F4E1}";
        offlineText.textContent = isOffline ? "Offline" : "Online";
      }
    });
    MEME_TEMPLATES.forEach((template) => {
      const btn = document.createElement("button");
      btn.className = "template-btn";
      btn.textContent = template.name;
      if (template.id === currentTemplate) btn.classList.add("active");
      btn.onclick = () => regenerate(template.id);
      templatesDiv.appendChild(btn);
    });
  }
  textEditor.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      isManualEdit = true;
      regenerate();
    }
  });
  async function regenerate(templateId) {
    loading.classList.add("show");
    try {
      const text = isManualEdit ? textEditor.textContent || "" : memeData.originalInput || memeData.text;
      const template = templateId || currentTemplate || await analyzeMemeContext(text);
      currentTemplate = template;
      const { watermarkedUrl, formattedText } = await generateMemeImage(template, text, isManualEdit, !!templateId);
      img.src = watermarkedUrl;
      if (!isManualEdit) textEditor.textContent = formattedText;
      memeData.imageUrl = watermarkedUrl;
      memeData.text = formattedText;
      memeData.template = template;
      document.querySelectorAll(".template-btn").forEach((btn) => btn.classList.remove("active"));
      const activeBtn = Array.from(document.querySelectorAll(".template-btn")).find(
        (btn) => btn.textContent === MEME_TEMPLATES.find((t) => t.id === template)?.name
      );
      activeBtn?.classList.add("active");
      isManualEdit = false;
    } catch (error) {
      alert("Regeneration failed: " + (error instanceof Error ? error.message : String(error)));
    } finally {
      loading.classList.remove("show");
    }
  }
  document.getElementById("downloadBtn")?.addEventListener("click", async () => {
    const response = await fetch(img.src);
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `meme-${Date.now()}.png`;
    a.click();
    URL.revokeObjectURL(url);
  });
  document.getElementById("shareBtn")?.addEventListener("click", async () => {
    const modal = document.createElement("div");
    modal.style.cssText = "position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.85); z-index: 999999; display: flex; align-items: center; justify-content: center;";
    const content = document.createElement("div");
    content.style.cssText = "background: white; border-radius: 20px; padding: 64px; max-width: 640px; position: relative; box-shadow: 0 20px 60px rgba(0,0,0,0.3);";
    const closeBtn = document.createElement("button");
    closeBtn.textContent = "\xD7";
    closeBtn.style.cssText = "position: absolute; top: 20px; right: 20px; background: transparent; border: none; width: 40px; height: 40px; font-size: 36px; cursor: pointer; color: #999;";
    closeBtn.onclick = () => modal.remove();
    const title = document.createElement("div");
    title.textContent = "Share Meme";
    title.style.cssText = "font-size: 24px; font-weight: 700; color: #333; margin-bottom: 16px; text-align: center;";
    const statusText = document.createElement("div");
    statusText.style.cssText = "font-size: 16px; font-weight: 700; color: #333; text-align: center; margin-bottom: 32px; min-height: 24px;";
    const buttonsContainer = document.createElement("div");
    buttonsContainer.style.cssText = "display: flex; justify-content: center; gap: 48px;";
    const platforms = [
      { name: "Twitter", icon: '<svg width="80" height="80" viewBox="0 0 24 24" fill="#1DA1F2"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>', url: "https://twitter.com/compose/tweet" },
      { name: "LinkedIn", icon: '<svg width="80" height="80" viewBox="0 0 24 24" fill="#0A66C2"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>', url: "https://www.linkedin.com/feed/" },
      { name: "Email", icon: '<svg width="80" height="80" viewBox="0 0 24 24" fill="#EA4335"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>', url: "mailto:" }
    ];
    platforms.forEach((platform) => {
      const btn = document.createElement("button");
      btn.innerHTML = platform.icon;
      btn.style.cssText = "background: transparent; border: none; cursor: pointer; padding: 20px; border-radius: 20px; transition: all 0.2s;";
      btn.onmouseover = () => {
        btn.style.transform = "scale(1.1)";
        btn.style.background = "#f5f5f5";
      };
      btn.onmouseout = () => {
        btn.style.transform = "scale(1)";
        btn.style.background = "transparent";
      };
      btn.onclick = async () => {
        statusText.textContent = "Text copied!";
        await navigator.clipboard.writeText(`Check this meme: ${memeData.text}`);
        await new Promise((resolve) => setTimeout(resolve, 1e3));
        statusText.textContent = "Image downloaded!";
        const response = await fetch(img.src);
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `meme-${Date.now()}.png`;
        a.click();
        URL.revokeObjectURL(url);
        await new Promise((resolve) => setTimeout(resolve, 2e3));
        window.open(platform.url, "_blank");
        modal.remove();
      };
      buttonsContainer.appendChild(btn);
    });
    content.appendChild(closeBtn);
    content.appendChild(title);
    content.appendChild(statusText);
    content.appendChild(buttonsContainer);
    modal.appendChild(content);
    modal.onclick = (e) => {
      if (e.target === modal) modal.remove();
    };
    document.body.appendChild(modal);
  });
  document.getElementById("regenerateBtn")?.addEventListener("click", async () => {
    loading.classList.add("show");
    try {
      const currentText = textEditor.textContent?.trim() || "";
      const hasTextChanged = currentText !== memeData.text;
      if (hasTextChanged) {
        const { watermarkedUrl, formattedText } = await generateMemeImage(currentTemplate, currentText, true, true);
        img.src = watermarkedUrl;
        textEditor.textContent = formattedText;
        memeData.imageUrl = watermarkedUrl;
        memeData.text = formattedText;
      } else {
        const text = memeData.originalInput || memeData.text;
        const template = await analyzeMemeContext(text, Date.now());
        currentTemplate = template;
        const { watermarkedUrl, formattedText } = await generateMemeImage(template, text, false, true);
        img.src = watermarkedUrl;
        textEditor.textContent = formattedText;
        memeData.imageUrl = watermarkedUrl;
        memeData.text = formattedText;
        memeData.template = template;
        document.querySelectorAll(".template-btn").forEach((btn) => btn.classList.remove("active"));
        const activeBtn = Array.from(document.querySelectorAll(".template-btn")).find(
          (btn) => btn.textContent === MEME_TEMPLATES.find((t) => t.id === template)?.name
        );
        activeBtn?.classList.add("active");
      }
    } catch (error) {
      alert("Regeneration failed: " + (error instanceof Error ? error.message : String(error)));
    } finally {
      loading.classList.remove("show");
    }
  });
  document.getElementById("closeBtn")?.addEventListener("click", () => {
    window.close();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") window.close();
  });
  var isOffline = false;
  var offlineIndicator = document.getElementById("offlineIndicator");
  var offlineIcon = document.getElementById("offlineIcon");
  var offlineText = document.getElementById("offlineText");
  offlineIndicator?.addEventListener("click", () => {
    isOffline = !isOffline;
    chrome.storage.local.set({ offlineMode: isOffline });
    if (offlineIcon && offlineText) {
      offlineIcon.textContent = isOffline ? "\u{1F4F4}" : "\u{1F4E1}";
      offlineText.textContent = isOffline ? "Offline" : "Online";
    }
  });
  chrome.storage.local.get(["offlineMode"], (data) => {
    isOffline = data.offlineMode || false;
    if (offlineIcon && offlineText) {
      offlineIcon.textContent = isOffline ? "\u{1F4F4}" : "\u{1F4E1}";
      offlineText.textContent = isOffline ? "Offline" : "Online";
    }
  });
})();
